//
//  CustomTextView.h
//  EnjoyYourLife
//
//  Created by Faiz Rasool on 4/26/13.
//  Copyright (c) 2013 Darussalam Publications. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomTextView : UITextView

@end
