//
//  NotesViewController.m
//  EnjoyYourLife
//
//  Created by Faiz Rasool on 4/1/13.
//  Copyright (c) 2013 D-Tech. All rights reserved.
//

#import "NotesViewController.h"

@interface NotesViewController ()

@end

@implementation NotesViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewWillAppear:(BOOL)animated{
    DataSource * ds = [DataSource sharedInstance];
    
    NSString * chapterNotes = [ds GetNotesForChapterId:self.chapterID ] ;
//    if(chapterNotes.count >= 2)
//    {
//        NSString *notesDate =[chapterNotes objectAtIndex:0];
//        NSString *notes = [chapterNotes objectAtIndex:1];
        [self.notesTextView setText:[NSString stringWithFormat:@"%@\n",chapterNotes]];
//    }
}


- (void)viewDidDisappear:(BOOL)animated{
    [self.notesTextView setText:@""];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.navigationItem.title = @"Notes";
    
//    [self.navigationController.navigationBar setBarStyle:UIBarStyleBlack];
//    [self.navigationController.navigationBar setTintColor:[UIColor colorWithRed:175.0/255.0 green:119.0/255.0 blue:135.0/255.0 alpha:1]];
    
//    UIButton * btn = [UIButton buttonWithType:UIButtonTypeCustom];
//    [btn setTitle:@"Cancel" forState:UIControlStateNormal];
//    [btn setBackgroundImage:[UIImage imageNamed:@"button@2x.png"] forState:UIControlStateNormal];
//    btn.titleLabel.font = [UIFont boldSystemFontOfSize:12];
//    btn.frame = CGRectMake(0, 0, 50, 30);
//    [btn addTarget:self action:@selector(cancelButtonTapped) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem * item = [[UIBarButtonItem alloc] initWithTitle:@"Cancel" style:UIBarButtonItemStyleBordered target:self action:@selector(cancelButtonTapped:)];
    //    item.image = [UIImage imageNamed:@"back.png"];
    self.navigationItem.leftBarButtonItem = item;

//    UIButton * saveBtn = [UIButton buttonWithType:UIButtonTypeCustom];
//    [saveBtn setTitle:@"Save" forState:UIControlStateNormal];
//    [saveBtn setBackgroundImage:[UIImage imageNamed:@"button@2x.png"] forState:UIControlStateNormal];
//    saveBtn.titleLabel.font = [UIFont boldSystemFontOfSize:12];
//    saveBtn.frame = CGRectMake(0, 0, 50, 30);
//    [saveBtn addTarget:self action:@selector(saveButtonTapped) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem * barItm = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStyleBordered target:self action:@selector(saveButtonTapped:)];
    //    item.image = [UIImage imageNamed:@"back.png"];
    self.navigationItem.rightBarButtonItem = barItm;

}

- (IBAction)saveButtonTapped:(id)sender{
    DataSource * ds = [DataSource sharedInstance];
    
    //if([self.notesTextView.text isEqualToString:@""])
    
    int error = [ds AddNotes:self.notesTextView.text ForChapterId:self.chapterID];
    if(error == 0){
        UIAlertView * alrt = [[UIAlertView alloc]initWithTitle:@"Notes saved successfully." message:nil delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        [alrt show];
        [self dismissModalViewControllerAnimated:YES];
    }
    
   // else
    //    [ds UpdateNotes:self.notesTextView.text ForChapterId:self.chapterID];
}

- (IBAction)cancelButtonTapped:(id)sender{
    [self dismissModalViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidUnload {
    [self setNotesTextView:nil];
    [super viewDidUnload];
}

@end
