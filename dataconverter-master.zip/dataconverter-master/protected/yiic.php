<?php

// change the following paths if necessary
$yiic=dirname(__FILE__).'/../../frameworks/yii-1.1.13.e9e4a0/framework/yiic.php';
$config=dirname(__FILE__).'/config/console.php';

require_once($yiic);
