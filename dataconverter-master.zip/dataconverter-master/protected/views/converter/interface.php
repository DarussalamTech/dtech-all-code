<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <script type="text/javascript" src="<?php echo Yii::app()->baseUrl ?>/js/jquery-1.8.0.min.js"></script>
        <script type="text/javascript" src="<?php echo Yii::app()->baseUrl ?>/js/json.js"></script>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>Data converter Document</title>
        <script>

            function saveData() {
                
                $("span#status").html("saving........");
                var rs = new Array();
                $("p").each(function() {
                    var t = $(this).text();
                    if ($.trim(t) != "") {
                        rs.push(t.split("\n"));
                    }
                })

                jsond = JSON.stringify(rs);

                
                $.post("<?php echo $this->createUrl("/converter/insert") ?>",
                        {
                            name: jsond,
                            db: $("#db").val(),
                        })
                        .done(function(data) {
                     $("span#status").html("");
                    alert("Data has been saved ");
                });
            }
            /**
             * 
             * @returns {undefined}
             */
            function download() {
                window.location.href = "<?php echo $this->createUrl("/converter/download") ?>&db=" + $("#db").val();
            }

        </script>
    </head>

    <body>
        <div style ="border:1px solid black;margin-left: auto;margin-right: auto">
            <?php
            echo CHtml::label("Database", "Database") . " = ";

            echo CHtml::dropDownList("db", "mysql", array(
                "mysqldb" => "mysql",
                "sqllitedb" => "sqlite"
            ));


            echo CHtml::tag("div", array("style" => "clear:both;margin-top:5px"));
            echo CHtml::button("Save data", array("onclick" => "
                    saveData();
                "));
            echo CHtml::openTag("span", array('style' => "margin-left:5px", "id" => "status"));
            echo CHtml::closeTag("span");

            echo CHtml::tag("div", array("style" => "clear:both;margin-top:5px"));
            echo CHtml::button("Download db File", array("onclick" => "
                    download();
                "));
            ?>
        </div>

        <div style="height: 40px"></div>

        <?php
            if(isset($_REQUEST['file'])){
                require_once Yii::app()->basePath."/views/converter/uploads/".$_REQUEST['file'];
            }
        ?>
    </body>
</html>