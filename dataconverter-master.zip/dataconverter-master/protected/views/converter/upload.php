<?php
Yii::app()->clientScript->registerCssFile(Yii::app()->baseUrl . '/css/form.css');
?>
<?php
$form = $this->beginWidget(
        'CActiveForm', array('id' => 'upload-form',
    'enableAjaxValidation' => false,
    'htmlOptions' => array('enctype' => 'multipart/form-data'),
        )
);
?>
<div class="form wide">
    <div class="row">
        <?php echo $form->labelEx($model, 'file'); ?>
        <?php echo $form->fileField($model, 'file'); ?>
        <?php echo $form->error($model, 'file'); ?>
    </div>
</div>

<div class="row buttons">
    <?php echo CHtml::submitButton('Save', array("class" => "btn")); ?>

</div>

<?php $this->endWidget(); ?> 