<p><strong>&lsquo;aabid (pl. &lsquo;ubbaad) </strong><br />
    عابد  (عباد)<br />
    Worshipper, devotee<br />
    A person devoted  to worshipping Allah. </p>
<p>&nbsp;</p>
<p><strong>&lsquo;aabiq</strong><br />
    <strong><span dir="ltr"> </span></strong>آبق<span dir="ltr"> </span><br />
    Runaway slave<br />
    A slave who runs away from his master for no legitimate reason. </p>
<p>&nbsp;</p>
<p><strong>&lsquo;aad</strong> <br />
    عاد<br />
    People  of &lsquo;Ad<br />
    A people  of the Arabian Peninsula to whom Allah  sent the Prophet  &ldquo;huud&rdquo; (Hood). It is said that they lived in the Yemen area. (See,  e.g.,<br />
    the Qur&rsquo;an, 11: 50-60).</p>
<p>&nbsp;</p>
<p>&lsquo;aadaab (sg. &lsquo;adab)<br />
    آداب۔ أدب<br />
    Manners, rules of conduct<br />
    Good morals  and manners are  mentioned by the Prophet (PBUH) as criteria  of  superiority  of  a  believer over others. A Muslim is supposed to observe  the laws of Islam in every aspect  of his life,</p>
<p><strong>&nbsp;</strong></p>
<p><strong>&lsquo;aadam</strong><br />
    آدم<span dir="ltr"> </span><br />
    The first human being created by  Allah. His mate was Eve. (See the Qur&rsquo;an, 2: 30-38 for references to his  creation, sin, repentance…)</p>
<p><strong>&nbsp;</strong></p>
<p><strong>aadil&lsquo;</strong><br />
    عادل<span dir="ltr"> </span><br />
    just, fair</p>
<p>&nbsp;</p>
<p> <strong>(al—&lsquo;aakhir) </strong><br />
    الآخر<span dir="ltr"> </span><br />
    The Last <br />
    A Divine Attribute of Allah. The One after  Whom no one and nothing exists, because  He is the Only Everlasting  Being.</p>
<p><strong>&nbsp;</strong></p>
<p><strong>(al-&lsquo;aakhirah)</strong><br />
    الآخرة<span dir="ltr"> </span><br />
    The Hereafter</p>
<p>Belief in life in the Hereafter (in the  physical and spiritual  senses) is one of the six corner-stones of &ldquo;&rsquo;iimaan&rdquo; (faith)  in Islam.<strong> </strong></p>
<p><strong>&nbsp;</strong></p>
<p><strong>&lsquo;aakil ar-riba</strong><br />
    آكل  الربا<span dir="ltr"> </span><br />
    Devourer of usury<br />
    Anyone who lends people money with interest / usury is guilty of devouring  it, which means he  purchases his food with money earned in that manner.<strong> </strong></p>
<p><strong>&nbsp;</strong></p>
<p><strong>&lsquo;aalam al-barzakh </strong><br />
    عالم  البرزخ<span dir="ltr"> </span><br />
    Intermediate state<br />
    See <strong>&ldquo;barzakh&rdquo;</strong>. </p>
<p><strong>&nbsp;</strong></p>
<p><strong>&lsquo;aal&lsquo; imraan </strong><br />
    آل  عمران<span dir="ltr"> </span><br />
    Family of Imran <br />
    In Chapter  3 of the Qur&rsquo;an, this  refers to the family of Maryam (Mary), the mother of &lsquo;iisaa (Jesus) (PBUH).</p>
<p><strong>&nbsp;</strong></p>
<p><strong>&lsquo;aal al-bayt</strong> <br />
    آل  البيت<span dir="ltr"> </span><br />
    family of the Prophet (PBUH) Literally,   the    members    of    the household.  The   term  is  used  to refer to the wives  of the Prophet (PBUH), his offspring  and Muslim uncles  and  cousins,  who  were forbidden to accept &ldquo;sadaqah&rdquo;.</p>
<p><strong>&nbsp;</strong></p>
<p><strong>&lsquo;aal muHammad </strong><br />
    آل  محمد<span dir="ltr"> </span><br />
    family of Muhammad See &lsquo;aal al-bayt.</p>
<p><strong>&nbsp;</strong></p>
<p><strong>&lsquo;aalaa (yuulii) </strong><br />
    آلى  يُولي<span dir="ltr"> </span><br />
    To decide  or make &lsquo;iilaa&rsquo;<br />
    See &lsquo;iilaa&rsquo; for the special sense of deciding to desert  one&rsquo;s wife in bed.</p>
<p><strong>&nbsp;</strong></p>
<p><strong>&lsquo;aalam al-ghayb </strong><br />
    عالم  الغىب<span dir="ltr"> </span><br />
    The unseen world<br />
    Literally, &lsquo;the world  of the unseen,&rsquo; including the future and the Hereafter, which is known only to  Allah. </p>
<p><strong>&lsquo;aalam ash-shahaadah</strong><br />
    عالم  الشهادة<span dir="ltr"> </span><br />
    The visible world</p>
<p>The present material  world, as opposed to the Hereafter  or the future, for example,  which are not visible or known to us. The opposite of &ldquo;&lsquo;aalam al-ghayb  &rdquo; (the unseen world).</p>
<p>&nbsp;</p>
<p>&lsquo;aalim (pl. &lsquo;ulamaa&lsquo;)<br />
    عالم  (علماء)<span dir="ltr"> </span><br />
    scholar<br />
    In Islamic texts,  the term usually refers to a scholar  specializing in religious fields of knowledge. </p>
<p><strong>&nbsp;</strong></p>
<p><strong>&lsquo;aam al-bu&lsquo;uuth</strong><br />
    عام  البعوث<span dir="ltr"> </span><br />
    Year of Deputations<br />
    The ninth year of the Hijrah is called the Year of Deputations,  because deputations came from all over Arabia to the Prophet  (PBUH) at Medina to declare their conversion to Islam and to learn about it.</p>
<p><strong>&nbsp;</strong></p>
<p><strong>&lsquo;aam al-fiil </strong><br />
    عام  الفيل<span dir="ltr"> </span><br />
    Year of the Elephant<br />
    The year 570 AD, when the Abyssinian viceroy in Yemen decided to invade Mecca and destroy the Ka&lsquo;bah with an army that had elephants, but they were  all miraculously  destroyed.  (See the Qur&rsquo;an, 105). It was in this year  that the Prophet Muhammad (PBUH) was born.</p>
<p><strong>&nbsp;</strong></p>
<p><strong>&lsquo;aamana (yu&lsquo;min) </strong><br />
    آمن  ىؤمن<span dir="ltr"> </span><br />
    To believe<br />
    When the verb is used in an  unqualified manner  in the Qur&rsquo;an it refers to believing  in Allah.</p>
<p><strong>&nbsp;</strong></p>
<p><strong>&lsquo;aamiin</strong><strong> </strong><br />
    آمين<span dir="ltr"> </span><br />
    Amen<br />
    May God answer   the   prayer!  The expression said at  the  end of the recitation  of the Opening Chapter of the Qur&rsquo;an, which ends with the prayer, &ldquo;Guide us to the Straight Path, the Path of those who gained Your Favour, not those who deserved Your wrath, nor those  who have gone astray.&rdquo; (the Qur&rsquo;an, 1: 6-7). It is often heard after hearing all types of supplication.</p>
<p><strong>&nbsp;</strong></p>
<p><strong>&lsquo;aaqib (al-) </strong><br />
    العاقب<span dir="ltr"> </span><br />
    The Last<br />
    The reference is to Prophet Muhammad (PBUH) being the last  Prophet and Messenger of Allah.</p>
<p><strong>&nbsp;</strong></p>
<p><strong>&lsquo;aaqilah </strong><br />
    عاقلة<span dir="ltr"> </span><br />
    Blood money payers<br />
    Relatives,  such  as  ancestors   or  descendants who are responsible<br />
    (with  the  murderer)  for  paying      Aa <br />
    the blood money to the family of the murdered victim.</p>
<p><strong>&nbsp;</strong></p>
<p><strong>&lsquo;aaqil 1 </strong><br />
    عاقل<span dir="ltr"> </span><br />
    Wise</p>
<p><strong>&nbsp;</strong></p>
<p><strong>&lsquo;aaqil 2 </strong><br />
    عاقل<span dir="ltr"> </span><br />
    Sane<br />
    Legally, this means someone who is of sound mind; therefore, he is responsible for his actions.</p>
<p><strong>&nbsp;</strong></p>
<p><strong>&lsquo;aariyyah </strong><br />
    عارية<span dir="ltr"> </span><br />
    Loaned object<br />
    Something borrowed from someone.  Naturally,  it  should be returned  intact as much as possible.</p>
<p>&nbsp;</p>
<p>&lsquo;aamil (pl. &lsquo;ummaal)<br />
    عامل  (عمال)<span dir="ltr"> </span><br />
    Governor<br />
    In classical  use, the governor appointed by the caliph to rule a certain  area in his name.</p>
<p>&nbsp;</p>
<p>&lsquo;aaS(in) (pl. &lsquo;uSaah)<br />
    عاص  (عصاة)<span dir="ltr"> </span><br />
    Sinner, rebellious<br />
    The term means   &lsquo;sinner&rsquo;  if  he is  rebellious  against Divine commands;  otherwise, it means a  persistently disobedient person.<strong> </strong></p>
<p><strong>&nbsp;</strong></p>
<p><strong>&lsquo;aashuuraa&lsquo;</strong><br />
    عاشوراء<span dir="ltr"> </span><br />
    Tenth of Muharram</p>
<p>The tenth day of the first month of Islamic calendar. It is sunnah to fast this day, with one day before or after  it. On this day also al-Husayn (grandson of the Prophet {PBUH}) was martyred at  Karbalaa&rsquo; in Iraq.</p>
<p>&nbsp;</p>
<p>&lsquo;aataa (yu&lsquo;tii) az-zakaah<br />
    آتي  يؤتي<span dir="ltr"> </span><br />
    give alms, pay the poor dues</p>
<p>Paying &ldquo;az-zakaah&rdquo; (poor dues) is one of the five pillars of Islam. It is paid on savings,  commodities, live stock as well as agricultural produce.</p>
<p>&nbsp;</p>
<p>&lsquo;aayah 1 (pl. &lsquo;aayaat)<br />
    آية (آيات)1<span dir="ltr"> </span><br />
    Sign</p>
<p>In the Qur&rsquo;an we are told that all types  of creation are signs from Allah for man to ponder upon,  hence reach the conclusion  of His greatness.</p>
<p>&nbsp;</p>
<p>&lsquo;aayah 2 (pl.&lsquo;aayaat)<br />
    آية (آيات)2<span dir="ltr"> </span><br />
    Verse<br />
    A verse from the Qur&rsquo;an (part of a  &ldquo;suurah&rdquo; (chapter).</p>
<p>&nbsp;</p>
<p> &lsquo;aayah 3 (pl.&lsquo;aayaat)<br />
    آية 3(آيات)<span dir="ltr"> </span><br />
    Proof, evidence</p>
<p><strong>&nbsp;</strong></p>
<p><strong>&lsquo;aayat al-kursiy </strong><br />
    آية الكرسي<span dir="ltr"> </span><br />
    Verse of the Throne<br />
    This refers to verse 256 of Chapter 2 of the Holy Qur&rsquo;an. It consists of ten sentences  about Allah, giving twenty of His  Attributes   and five of His Names. The Prophet (PBUH) strongly recommended reciting it after regular &ldquo;Salaah&rdquo; as well as before going to bed, as a source of protection  for a Muslim from Satan and other evils.</p>
<p><strong>&nbsp;</strong></p>
<p><strong>Aazar </strong><br />
    آزر<span dir="ltr"> </span><br />
    Terah<br />
    Prophet  Abraham&rsquo;s   father.  (See the Qur&rsquo;an 6:74).</p>
<p>&nbsp;</p>
<p>abaaHa (yubiiH)<br />
    أباح (يبيح)<span dir="ltr"> </span><br />
    To permit or make lawful</p>
<p><strong>&nbsp;</strong></p>
<p><strong>Abad</strong><br />
    أبد<span dir="ltr"> </span><br />
    Forever<br />
    This is usually contrasted with &ldquo;&lsquo;azal&rdquo; (time immemorial). It refers to time that has no end.</p>
<p>&nbsp;</p>
<p>&lsquo;abd 1 (pl. &lsquo;abiid)<br />
    عبد 1 (عبيد)<span dir="ltr"> </span><br />
    male slave, bondsman <br />
    A slave was a   man    captured in a just war or the son of a bondswoman. </p>
<p>&nbsp;</p>
<p>&lsquo;abd 2 (pl. &lsquo;ibaad)<br />
    عبد 2(عباد)<span dir="ltr"> </span><br />
    Servant, worshipper</p>
<p>In the  context of man&rsquo;s  relationship to Allah,  the word is usually translated &lsquo;servant&rsquo;.</p>
<p>&nbsp;</p>
<p>&lsquo;ablagha (yubligh)<br />
    أبلغ (يبلغ)<span dir="ltr"> </span><br />
    To convey<br />
    To convey a message.</p>
<p>&nbsp;</p>
<p>&lsquo;abraar (sg. barr(un)<br />
    أبرار (بر)<span dir="ltr"> </span><br />
    righteous people</p>
<p>&nbsp;</p>
<p>&lsquo;abTala (yubTil)<br />
    أبطل (يبطل)<span dir="ltr"> </span><br />
    To invalidate</p>
<p>To make  something or some  action invalid, such as laughing  which makes &ldquo;Salaah&rdquo;  (prayer) invalid. </p>
<p><strong>&lsquo;adaa&lsquo; 1</strong><br />
    أداء <span dir="ltr"> </span><br />
    performance<br />
    Performing a religious  rite, such as formal prayers and pilgrimage<br />
    to Mecca.                                                  Aa </p>
<p><strong>&nbsp;</strong></p>
<p><strong>&lsquo;adaa&lsquo; 2</strong><br />
    أداء2<span dir="ltr"> </span><br />
    Payment<br />
    Paying back a loan or debt.</p>
<p><strong>&nbsp;</strong></p>
<p><strong>&lsquo;adaalah </strong><br />
    عدالة<span dir="ltr"> </span><br />
    Justice, integrity<br />
    In the science of hadeeth, the term  means the integrity  (of the narrator).</p>
<p><strong>&nbsp;</strong></p>
<p><strong>adab (pl. aadaab)</strong><br />
    أدب آداب<span dir="ltr"> </span><br />
    Rule of behaviour / etiquette See &ldquo; &lsquo;aadaab.&rdquo; </p>
<p>&nbsp;</p>
<p>addaa (yu&lsquo;addii) <br />
    أدّى (يؤدي)<span dir="ltr"> </span><br />
    to do<br />
    In the case of&rdquo; Salaah&rdquo; (formal prayer) this means &lsquo;to perform&rsquo; while for &ldquo;zakaah&rdquo;  it means paying it.</p>