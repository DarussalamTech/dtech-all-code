<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class ConverterController extends Controller {

    public function actionInterface() {
        $this->layout = "";


        $this->renderPartial("interface");
    }
    public function actionUpload() {
        $this->layout = "";
        $model = new File;
        
        if(isset($_POST['File'])){
            $model->attributes = $_POST['File'];
            if($model->validate()){
                $upload_path = Yii::app()->basePath."/views/converter/uploads/";
                $user_file = DTUploadedFile::getInstance($model, 'file');
                if (!empty($user_file)) {
                    $user_file->saveAs($upload_path . $user_file->name);
                    $this->redirect($this->createUrl("/converter/interface",array("file"=>$user_file->name)));
                }
            }
        }

        $this->renderPartial("upload",array("model"=>$model));
    }

    public function actionInsert() {
        if (isset($_POST['name'])) {
            $post = json_decode($_POST['name']);

            foreach ($post as $data) {


                $input = new Inputdata();
                $input->word = trim($data[0]);
                $input->arabic = isset($data[1]) ? trim($data[1]) : "";
                $input->meaning = isset($data[2]) ? trim($data[2]) : "";
                ;
                $input->description = isset($data[3]) ? trim($data[3]) : "";
                $input->save();
            }
        }
        $this->renderPartial("insert");
    }

    /**
     * 
     */
    public function actionDownload() {
        if ($_REQUEST['db'] == "sqllitedb") {
            $path = Yii::app()->basePath . "/data/sqllite.db";
            if (file_exists($path)) {
                return Yii::app()->getRequest()->sendFile('sqllite.db', @file_get_contents($path));
            }
        } else {
            $input = new Inputdata();
            $input->getDbConnection();
            Yii::import('ext.yii-database-dumper-master.SDatabaseDumper');
            $dumper = new SDatabaseDumper;
            // Get path to backup file
            $file = Yii::getPathOfAlias('webroot.protected.data') . DIRECTORY_SEPARATOR . 'dump_' . date('Y-m-d_H_i_s') . '.sql';
            
           
            // Gzip dump
            if (function_exists('gzencode')){
                file_put_contents($file . '.gz', gzencode($dumper->getDump()));
                $file = $file . '.gz';
            }
            else{
                file_put_contents($file, $dumper->getDump());
            }

            return Yii::app()->getRequest()->sendFile($file, @file_get_contents($file));
        }
    }

}

?>
