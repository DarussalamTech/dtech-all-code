//
//  TouchSprite.h
//  Touching Sprites
//
//  Created by Faiz Rasool on 6/19/13.
//  Copyright 2013 D-Tech. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "Alphabet.h"

@interface TouchSprite : CCSprite <CCTouchOneByOneDelegate> {
    
}
@property (nonatomic, strong) Alphabet * alphabet;

-(BOOL) tsTouchBegan:     (UITouch*)touch withEvent: (UIEvent*)event;
-(void) tsTouchMoved:     (UITouch*)touch withEvent: (UIEvent*)event;
-(void) tsTouchEnded:     (UITouch*)touch withEvent: (UIEvent*)event;
-(void) tsTouchCancelled: (UITouch*)touch withEvent: (UIEvent*)event;

@end