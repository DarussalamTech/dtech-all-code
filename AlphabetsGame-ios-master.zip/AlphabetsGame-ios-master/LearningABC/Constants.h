//
//  Constants.h
//  LearningABC
//
//  Created by Faiz Rasool on 6/3/13.
//  Copyright (c) 2013 D-Tech. All rights reserved.
//

#import "BubbleSprite.h"
#import "CCSprite+Resize.h"
#import "SimpleAudioEngine.h"
#import "Utility.h"
#import "Alphabet.h"

/////////// Delays //////////////
#pragma mark - Delays

#define kReplaceSceneDelay 0.5f
#define kScheduleDelay 10.0f

//////////// Tags //////////////
#pragma mark - Tags

#define kPlayMenuButtonTag 1
#define kEducateMenuButtonTag 2

#define kPlayArabicButtonTag 3
#define kPlayEnglishButtonTag 4
#define kPlayMathsButtonTag 5
#define kPlayArabicMathsButtonTag 6

#define kEducateArabicButtonTag 7
#define kEducateEnglishButtonTag 8
#define kEducateMathsButtonTag 9
#define kEducateArabicMathsButtonTag 10

#define kSoundButtonTag 11
#define kPlayPauseButtonTag 12
#define kLearnButtonTag 13
#define kHomeButtonTag 14
#define kPlaySoundButtonTag 15
#define kGameButtonTag 16

#define kSettingsMenuButtonTag 17

///////////// Sounds ////////////////
#define kButtonClickSound @"test.caf"
#define kBackgroundMusicSound @"3.mp3"
#define kBackgroundSoundEffect @"explosion-01.wav"

////////// Game Types /////////////

#define kGameTypeEnglish @"kGameTypeEnglish"
#define kGameTypeArabic @"kGameTypeArabic"
#define kGameTypeMaths @"kGameTypeMaths"
#define kGameTypeArabicMaths @"kGameTypeArabicMaths"

NSString * selectedGameType;

////////// Learning Types //////////
#define kLearningTypeEnglish 1
#define kLearningTypeArabic 2
#define kLearningTypeMaths 3
#define kLearningTypeArabicMaths 4

int selectedLearningType;
Alphabet * currentlySelectedAlphabet;
int selectedGameInterface;

#define isDeviceIphone [[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone
#define isDeviceIpad [[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad

#define kCorrectBubbleTappedNotification @"CorrectBubbleTappedNotification"
#define kWrongBubbleTappedNotification @"WrongBubbleTappedNotification"

#define kBoyDefaultFileName @"boy_default"
#define kBoyHappyAnimationFileName @"boy_happy"
#define kBoySadAnimationFileName @"boy_sad"

#define kGirlHappyAnimationFileName @"girl_happy"
#define kGirlSadAnimationFileName @"girl_sad"
#define kGirlDefaultAnimationFileName @"girl_default"

#define isIphone5 [[CCDirector sharedDirector] winSize].width > 480
