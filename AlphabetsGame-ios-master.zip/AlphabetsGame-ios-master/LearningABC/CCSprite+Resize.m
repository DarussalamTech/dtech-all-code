//
//  CCSprite+Resize.m
//  LearningABC
//
//  Created by Faiz Rasool on 6/14/13.
//  Copyright (c) 2013 D-Tech. All rights reserved.
//

#import "CCSprite+Resize.h"

@implementation CCSprite (Resize)

- (CGRect)rectInPixels
{
    CGSize s = [_texture contentSizeInPixels];
    return CGRectMake(-s.width / 2, -s.height / 2, s.width, s.height);
}

- (CGRect)rect
{
    CGSize s = [self.texture contentSize];
    return CGRectMake(-s.width / 2, -s.height / 2, s.width, s.height);
}

- (BOOL)containsTouchLocation:(UITouch *)touch
{
    CGPoint p = [self convertTouchToNodeSpaceAR:touch];
    CGRect r = [self rectInPixels];
    r.origin = CGPointZero;
    return CGRectContainsPoint(r, p);
}

-(void)resizeTo:(CGSize) theSize
{
    CGFloat newWidth = theSize.width;
    CGFloat newHeight = theSize.height;
    
    
    float startWidth = self.contentSize.width;
    float startHeight = self.contentSize.height;
    
    float newScaleX = newWidth/startWidth;
    float newScaleY = newHeight/startHeight;
    
    self.scaleX = newScaleX;
    self.scaleY = newScaleY;
    
}

@end
