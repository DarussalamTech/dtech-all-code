//
//  Utility.m
//  LearningABC
//
//  Created by Faiz Rasool on 6/4/13.
//  Copyright (c) 2013 D-Tech. All rights reserved.
//

#import "Utility.h"
#import "Alphabet.h"

@implementation Utility

static Utility * util = nil;

+ (Utility*) sharedUtility{
   if(util == nil)
       util = [[Utility alloc]init];
    
    return util;
}

#pragma mark - Playing Sounds

+ (void) playButtonSound{
//    [SimpleAudioEngine sharedEngine].mute = NO;
    [[SimpleAudioEngine sharedEngine]playEffect:kButtonClickSound];
}

+ (void) playBackgroundMusic:(NSString*)music{
//    [SimpleAudioEngine sharedEngine].mute = NO;
    [[SimpleAudioEngine sharedEngine]playBackgroundMusic:kBackgroundMusicSound loop:YES];
    
}

+ (void) playSoundEffect:(NSString*)sound{
//    [SimpleAudioEngine sharedEngine].mute = NO;
    [[SimpleAudioEngine sharedEngine]playEffect:sound];
}

+ (NSArray*) loadAlphabetsOfType:(int)alphabetsType{
    
    NSString * plistName = nil;
    switch (alphabetsType) {
        case kLearningTypeEnglish:
            plistName = @"EnglishLearning";
            break;
        case kLearningTypeArabic:
            plistName = @"ArabicLearning";
            break;
        case kLearningTypeArabicMaths:
            plistName = @"ArabicMathsLearning";
            break;
        case kLearningTypeMaths:
            plistName = @"MathsLearning";
            break;
        default:
            break;
    }
    
    NSString * path = [[NSBundle mainBundle] pathForResource:plistName ofType:@"plist"];
    NSDictionary * plistData = [NSDictionary dictionaryWithContentsOfFile:path];
    NSArray * arr = [plistData objectForKey:@"Letters"];
    
    NSMutableArray * objects = [NSMutableArray array];
    
    for(NSDictionary * dict in arr){
        Alphabet * alp = [[[Alphabet alloc]init] autorelease];
        alp.letter = [[dict objectForKey:@"Alphabet"] intValue];
        alp.imageName = [dict objectForKey:@"Image"];
        alp.soundName = [dict objectForKey:@"Sound"];
        [objects addObject:alp];
    }
    
    
    return objects;
}

@end
