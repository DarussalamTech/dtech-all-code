//
//  CCSprite+Resize.h
//  LearningABC
//
//  Created by Faiz Rasool on 6/14/13.
//  Copyright (c) 2013 D-Tech. All rights reserved.
//

#import "CCSprite.h"

@interface CCSprite (Resize)

@property(nonatomic, readonly) CGRect rect;
@property(nonatomic, readonly) CGRect rectInPixels;

- (BOOL)containsTouchLocation:(UITouch *)touch;

-(void)resizeTo:(CGSize) theSize;

@end
