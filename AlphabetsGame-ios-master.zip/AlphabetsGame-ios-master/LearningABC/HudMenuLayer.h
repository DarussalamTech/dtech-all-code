//
//  MainMenuLayer.h
//  LearningABC
//
//  Created by Faiz Rasool on 5/30/13.
//  Copyright 2013 D-Tech. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface HudMenuLayer : CCLayer {
   CCLabelBMFont * _statusLabel;
}

+(CCScene *) scene;

@end
