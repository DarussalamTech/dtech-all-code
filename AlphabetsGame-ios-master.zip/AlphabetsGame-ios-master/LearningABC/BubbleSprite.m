//
//  BubbleSprite.m
//  LearningABC
//
//  Created by Faiz Rasool on 6/11/13.
//  Copyright 2013 D-Tech. All rights reserved.
//

#import "BubbleSprite.h"


@implementation BubbleSprite

- (CGRect)rect
{
    CGSize s = [self.texture contentSize];
    return CGRectMake(-s.width / 2, -s.height / 2, s.width, s.height);
}

+ (id)spuButtonWithTexture:(CCTexture2D *)normalTexture
{
    return [[[self alloc] initWithTexture:normalTexture] autorelease];
}

- (void)setNormalTexture:(CCTexture2D *)normalTexture {
    buttonNormal = normalTexture;
}

- (void)setLitTexture:(CCTexture2D *)litTexture {
    buttonLit = litTexture;
}

- (BOOL)isPressed {
    if (state == kButtonStateNotPressed) return NO;
    if (state == kButtonStatePressed) return YES;
    return NO;
}

- (BOOL)isNotPressed {
    if (state == kButtonStateNotPressed) return YES;
    if (state == kButtonStatePressed) return NO;
    return YES;
}

- (id)initWithTexture:(CCTexture2D *)aTexture
{
    if ((self = [super initWithTexture:aTexture]) ) {
        
        state = kButtonStateNotPressed;
    }
    
    return self;
}

- (void)onEnter
{
    [[[CCDirector sharedDirector] touchDispatcher] addTargetedDelegate:self priority:0 swallowsTouches:YES];
    [super onEnter];
}

- (void)onExit
{
    [[[CCDirector sharedDirector] touchDispatcher] removeDelegate:self];
    [super onExit];
}

- (BOOL)containsTouchLocation:(UITouch *)touch
{
    return CGRectContainsPoint(self.rect, [self convertTouchToNodeSpaceAR:touch]);
}

- (BOOL)ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event
{/*
    if (state == kButtonStatePressed) return NO;
    if ( ![self containsTouchLocation:touch] ) return NO;
    if (buttonStatus == kButtonStatusDisabled) return NO;
    
    state = kButtonStatePressed;
   // [self setTexture:buttonLit];
    */
    [self pauseSchedulerAndActions];
    return YES;
}

- (void)ccTouchMoved:(UITouch *)touch withEvent:(UIEvent *)event
{
    // If it weren't for the TouchDispatcher, you would need to keep a reference
    // to the touch from touchBegan and check that the current touch is the same
    // as that one.
    // Actually, it would be even more complicated since in the Cocos dispatcher
    // you get NSSets instead of 1 UITouch, so you'd need to loop through the set
    // in each touchXXX method.
//    
//    if ([self containsTouchLocation:touch]) return;
//    //if (buttonStatus == kButtonStatusDisabled) return NO;
//    
//    state = kButtonStateNotPressed;
//    [self setTexture:buttonNormal];
//    
}

- (void)ccTouchEnded:(UITouch *)touch withEvent:(UIEvent *)event
{
    
    if([self containsTouchLocation:touch]){

    [Utility playSoundEffect:@"explosion-01.wav"];
    CCFadeOut * fade = [CCFadeOut actionWithDuration:1.0];
    [self runAction:fade];

//    [self performSelector:@selector(removeAllChildrenWithCleanup:) withObject:[NSNumber numberWithBool:YES] afterDelay:0.1];
//    [self performSelector:@selector(removeFromParentAndCleanup:) withObject:[NSNumber numberWithBool:YES] afterDelay:0.1];

    
    //[self performSelector:@selector(stopAllActions) withObject:nil afterDelay:0.1];
    [self stopAllActions];
//    UIAlertView * alrt = [[UIAlertView alloc]initWithTitle:[NSString stringWithFormat:@"Baloon tag is %d",self.tag] message:nil delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles: nil];
//    [alrt show];
//    [alrt release];
    

    }
}

-(void)resizeTo:(CGSize) theSize
{
    CGFloat newWidth = theSize.width;
    CGFloat newHeight = theSize.height;
    
    
    float startWidth = self.contentSize.width;
    float startHeight = self.contentSize.height;
    
    float newScaleX = newWidth/startWidth;
    float newScaleY = newHeight/startHeight;
    
    self.scaleX = newScaleX;
    self.scaleY = newScaleY;
    
}

- (void)dealloc{

    [super dealloc];
}

@end