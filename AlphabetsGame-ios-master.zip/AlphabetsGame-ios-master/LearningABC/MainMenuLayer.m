//
//  MainMenuLayer.m
//  LearningABC
//
//  Created by Faiz Rasool on 5/30/13.
//  Copyright 2013 D-Tech. All rights reserved.
//

#import "MainMenuLayer.h"
#import "EducateMenuLayer.h"
// Needed to obtain the Navigation Controller
#import "AppDelegate.h"
#import "GameMenuLayer.h"

@implementation MainMenuLayer
// Helper class method that creates a Scene with the HelloWorldLayer as the only child.
+(CCScene *) scene
{    
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	MainMenuLayer *layer = [MainMenuLayer node];
	
	// add layer as a child to scene
	[scene addChild: layer];
	
	// return the scene
	return scene;
}

// on "init" you need to initialize your instance
-(id) init
{
	// always call "super" init
	// Apple recommends to re-assign "self" with the "super's" return value
	if( (self=[super init]) ) {
        
        [self setupInterface];
        
        /*
         CGPoint point1 = CGPointMake(570, 160);
         CGPoint point2 = CGPointMake(100,100);
         id FwdactionMove = [CCMoveTo actionWithDuration:1 position:point1];
         id ReverseactionMove = [CCMoveTo actionWithDuration:1 position:point2];
         id actionMoveDone = [CCCallFuncN actionWithTarget:self selector:@selector(done1:)];
         //[menu runAction:[CCSequence actions:FwdactionMove, ReverseactionMove,actionMoveDone, nil]];
         
         
         
         ccBezierConfig bezier;
         bezier.controlPoint_1 = ccp(menu.boundingBox.origin.x, menu.boundingBox.origin.y);
         bezier.controlPoint_2 = ccp(200, size.height/6);
         bezier.endPosition = ccp(50,100);
         
         //        id bezierForward = [CCBezierBy actionWithDuration:3 bezier:bezier];
         id bezierForward = [CCBezierTo actionWithDuration:3 bezier:bezier];
         [menu runAction:ReverseactionMove];
         */
        //        [Utility playBackgroundMusic:kBackgroundMusicSound];
        
        /*
         CCSpriteBatchNode *danceSheet = [CCSpriteBatchNode batchNodeWithFile:@"boy_animation_default.png"];
         danceSheet.position = ccp(size.width/2, size.height/2);
         [self addChild:danceSheet];
         CCSprite *danceSprite = [CCSprite spriteWithTexture:danceSheet.texture rect:CGRectMake(0, 0, 236, 280)];
         [danceSheet addChild:danceSprite];
         CCAnimation *danceAnimation = [CCAnimation animation];
         int frameCount = 0;
         for (int y = 0; y < 1; y++) {
         for (int x = 0; x < 3; x++) {
         //CCSpriteFrame *frame = [CCSpriteFrame frameWithTexture:danceSheet.texture rect:CGRectMake(x*85,y*121,85,121) offset:ccp(0,0)];
         CCSpriteFrame * frame = [CCSpriteFrame frameWithTexture:danceSheet.texture rect:CGRectMake(x*85,y*121,85,121)];
         [danceAnimation addSpriteFrame:frame];
         frameCount++;
         if (frameCount == 4)
         break;
         }
         }
         
         CCAnimate *danceAction = [CCAnimate actionWithAnimation:danceAnimation];
         CCRepeatForever *repeat = [CCRepeatForever actionWithAction:danceAction];
         [danceSprite runAction:repeat];
         */
    }
	return self;
}

- (void) setupInterface{
    
    CGSize size = [[CCDirector sharedDirector] winSize];
    
    CCSprite *background = nil;
    
    NSString * postfix = nil;
    
    switch (selectedGameInterface) {
        case 0:
            postfix = @"_boy.png";
            break;
        case 1:
            postfix = @"_girl.png";
            break;
        default:
            break;
    }
    
    if( UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {
        if(isIphone5)
            background = [CCSprite spriteWithFile:[@"bg@2x" stringByAppendingString:postfix]];
        else
            background = [CCSprite spriteWithFile:[@"bg" stringByAppendingString:postfix]];
        }

    background.position = ccp(size.width/2, size.height/2);
    // bg.rotation = 90;
    [self addChild:background];
    
    // create a menu item using existing sprites
    CCSprite* normal = [CCSprite spriteWithFile:@"gamesbtn.png"];
    CCSprite* selected = [CCSprite spriteWithFile:@"gamesbtn_rollover.png"];
    CCMenuItemSprite* item2 = [CCMenuItemSprite
                               itemWithNormalSprite:normal
                               selectedSprite:selected
                               target:self
                               selector:@selector(playMenuItemTouched:)];
    item2.tag = kPlayMenuButtonTag;
    //item2.position = ccp(size.width/2, size.height/2);
    [item2 setAnchorPoint:ccp(-1.7, 1.1)];
    
    // create a menu item using existing sprites
    CCSprite* normal2 = [CCSprite spriteWithFile:@"learnbtn.png"];
    CCSprite* selected2 = [CCSprite spriteWithFile:@"learnbtn_rollover.png"];
    CCMenuItemSprite* item4 = [CCMenuItemSprite
                               itemWithNormalSprite:normal2
                               selectedSprite:selected2
                               target:self
                               selector:@selector(educateMenuItemTouched:)];
    item4.tag = kEducateMenuButtonTag;
    [item4 setAnchorPoint:ccp(-0.7, 0.1)];
    
    CCSprite* settingsNormal = [CCSprite spriteWithFile:@"settingsIcon.png"];
    CCSprite* selected3 = [CCSprite spriteWithFile:@"settingsIcon-rollover.png"];
    CCMenuItemSprite* item3 = [CCMenuItemSprite
                               itemWithNormalSprite:settingsNormal
                               selectedSprite:selected3
                               target:self
                               selector:@selector(settingsMenuItemTouched:)];
    item3.tag = kSettingsMenuButtonTag;
    [item3 setAnchorPoint:ccp(2.5, 1.0)];
    
    // create the menu using the items
    CCMenu* menu = [CCMenu menuWithItems:item2, item4, item3 ,nil];
    //CGSize size = [[CCDirector sharedDirector]winSize];
    // menu.position = CGPointMake(size.width/2, size.height/2);
    [self addChild:menu];
    // aligning is important, so the menu items don't occupy the same location
    [menu alignItemsHorizontallyWithPadding:40];
    
    
//    CCMenu * settingsMenu = [CCMenu menuWithItems:item3,nil];

    //[self addChild:settingsMenu];
}

- (void) done1:(id)sender{
    [[CCDirector sharedDirector ] pause];
}

//- (void)draw{
//    CGSize size = [[CCDirector sharedDirector]winSize];
//    glColor4f(255, 255, 255, 255);
//    CGPoint center = ccp(size.width/2, size.height/2);
//    CGFloat radius = 100.f;
//    CGFloat angle = 360.f;
//    NSInteger segments = 10;
//    BOOL drawLineToCenter = YES;
//
//    ccDrawCircle(center, radius, angle, segments, drawLineToCenter);
//}

- (void) playMenuItemTouched:(id)sender{
    [Utility playButtonSound];
    [[CCDirector sharedDirector]replaceScene:[CCTransitionFade transitionWithDuration:kReplaceSceneDelay scene:[GameMenuLayer scene]]];
}

- (void) educateMenuItemTouched:(id)sender{
    [Utility playButtonSound];
    [[CCDirector sharedDirector]replaceScene:[CCTransitionFade transitionWithDuration:kReplaceSceneDelay scene:[EducateMenuLayer scene]]];
}

- (void) settingsMenuItemTouched:(id)sender{
    [Utility playButtonSound];
    [[CCDirector sharedDirector]replaceScene:[CCTransitionFade transitionWithDuration:kReplaceSceneDelay scene:[SelectInterfaceLayer scene]]];
}

// on "dealloc" you need to release all your retained objects
- (void) dealloc
{
	// in case you have something to dealloc, do it in this method
	// in this particular example nothing needs to be released.
	// cocos2d will automatically release all the children (Label)
	// don't forget to call "super dealloc"
	[super dealloc];
}

-(void) onEnter
{
    // Called right after a node’s init method is called.
    // If using a CCTransitionScene: called when the transition begins.
    [super onEnter];
}

-(void) onEnterTransitionDidFinish
{
}

-(void) onExit
{
    // Called right before node’s dealloc method is called.
    // If using a CCTransitionScene: called when the transition has ended.
    [super onExit];
}


@end
