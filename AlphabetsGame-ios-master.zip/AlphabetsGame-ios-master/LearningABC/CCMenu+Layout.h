//
//  CCMenu+Layout.h
//  LearningABC
//
//  Created by Faiz Rasool on 6/10/13.
//  Copyright (c) 2013 D-Tech. All rights reserved.
//
#import "cocos2d.h"
#import "CCMenu.h"

@interface CCMenu (Layout)

- (void)alignItemsInGridWithPadding:(CGPoint)padding columns:(NSInteger)columns;

@end