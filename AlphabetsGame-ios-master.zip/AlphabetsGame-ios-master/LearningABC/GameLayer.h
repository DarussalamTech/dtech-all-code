//
//  GameLayer.h
//  LearningABC
//
//  Created by Faiz Rasool on 6/5/13.
//  Copyright 2013 D-Tech. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "EducateMenuLayer.h"
#import "Alphabet.h"
#import "CCTouchDispatcher.h"
#import "TouchSprite.h"

@interface GameLayer : CCLayer {
    CCLabelTTF * correctLabel;
    CCLabelTTF * wrongLabel;
    
    int correctCounter;
    int wrongCounter;
    CCArray * onScreenAlphabets;
    CCSpriteBatchNode *batchNode;
    NSMutableArray *animFrames;
    CCAnimation *animation;
    CCSprite *sprite;
}

@property (nonatomic, retain) NSArray * alphabets;
@property (nonatomic, retain) NSArray * bubbles;

+(CCScene *) scene;

@end
