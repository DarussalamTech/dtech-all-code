//
//  EducateMenuLayer.m
//  LearningABC
//
//  Created by Faiz Rasool on 5/31/13.
//  Copyright 2013 D-Tech. All rights reserved.
//

#import "EducateMenuLayer.h"
#import "CCMenu+Layout.h"

@implementation EducateMenuLayer

+(CCScene *) scene
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	EducateMenuLayer *layer = [EducateMenuLayer node];
	
	// add layer as a child to scene
	[scene addChild: layer];
    
	// return the scene
	return scene;
}

// on "init" you need to initialize your instance
-(id) init
{
	// always call "super" init
	// Apple recommends to re-assign "self" with the "super's" return value
	if( (self=[super init]) ) {
        [self setTouchEnabled:YES];
//        // background image
        
        CGSize size = [[CCDirector sharedDirector] winSize];
        
        CCSprite *background = nil;
        
        NSString * postfix = nil;
        
        switch (selectedGameInterface) {
            case 0:
                postfix = @"_boy.png";
                break;
            case 1:
                postfix = @"_girl.png";
                break;
            default:
                break;
        }
        
        if( UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {
            if(isIphone5)
                background = [CCSprite spriteWithFile:[@"bg@2x" stringByAppendingString:postfix]];
            else
                background = [CCSprite spriteWithFile:[@"bg" stringByAppendingString:postfix]];
        }

        
        background.position = ccp(size.width/2, size.height/2);
        [self addChild:background];

        
//        CCSprite * back = [CCSprite spriteWithFile:@"English.png"];
//        back.position = CGPointMake(0, size.height);
//        [self addChild:back];
        
       // CCMenuItemFont * back = [CCMenuItemFont itemWithString:@"Back" target:self selector:@selector(backButtonTouched:)];
        CCSprite* bNormal = [CCSprite spriteWithFile:@"home.png"]; //normal.color = ccRED;
        CCSprite* bSelected = [CCSprite spriteWithFile:@"home_rollover.png"];
        CCMenuItemSprite* back = [CCMenuItemSprite
                                   itemWithNormalSprite:bNormal
                                   selectedSprite:bSelected
                                   target:self
                                   selector:@selector(backButtonTouched:)];
        CCMenu * bMenu = [CCMenu menuWithItems:back, nil];
        
        bMenu.position = ccp(20, size.height - 20);
        
        [self addChild:bMenu];
        
        // create a menu item using existing sprites
        CCSprite* normal = [CCSprite spriteWithFile:@"abcbtn.png"]; //normal.color = ccRED;
        CCSprite* selected = [CCSprite spriteWithFile:@"abcbtn_rollover.png"];
        CCMenuItemSprite* item2 = [CCMenuItemSprite
                                   itemWithNormalSprite:normal
                                   selectedSprite:selected
                                   target:self
                                   selector:@selector(menuItemTouched:)];
        item2.tag = kEducateEnglishButtonTag;
        item2.anchorPoint = ccp(-1.6, -0.2);
        
        // create a menu item using existing sprites
        CCSprite* normal2 = [CCSprite spriteWithFile:@"aikbtn.png"]; //normal.color = ccRED;
        CCSprite* selected2 = [CCSprite spriteWithFile:@"aikbtn_rollover.png"];
        CCMenuItemSprite* item4 = [CCMenuItemSprite
                                   itemWithNormalSprite:normal2
                                   selectedSprite:selected2
                                   target:self
                                   selector:@selector(menuItemTouched:)];
        item4.tag = kEducateArabicMathsButtonTag;
        item4.anchorPoint = ccp(1.9, 1.3);
        
        // create a menu item using existing sprites
        normal = [CCSprite spriteWithFile:@"123btn.png"]; //normal.color = ccRED;
        selected = [CCSprite spriteWithFile:@"123btn_rollover.png"];
        CCMenuItemSprite* item3 = [CCMenuItemSprite
                                   itemWithNormalSprite:normal
                                   selectedSprite:selected
                                   target:self
                                   selector:@selector(menuItemTouched:)];
        item3.tag = kEducateMathsButtonTag;
        item3.anchorPoint = ccp(-0.2, 0.8);
        
        // create a menu item using existing sprites
        normal2 = [CCSprite spriteWithFile:@"alifbtn.png"]; //normal.color = ccRED;
        selected2 = [CCSprite spriteWithFile:@"alifbtn_rollover.png"];
        CCMenuItemSprite* item1 = [CCMenuItemSprite
                                   itemWithNormalSprite:normal2
                                   selectedSprite:selected2
                                   target:self
                                   selector:@selector(menuItemTouched:)];
        item1.tag = kEducateArabicButtonTag;
        item1.anchorPoint = ccp(-0.5, 1.3);
        
        // create the menu using the items
        CCMenu* menu = [CCMenu menuWithItems:item1, item2, item3, item4, nil];
        menu.position = CGPointMake(size.width/2, size.height/2);
        [self addChild:menu];
        // aligning is important, so the menu items don't occupy the same location
        //[menu alignItemsInColumns:[NSNumber numberWithInt:2],[NSNumber numberWithInt:2], nil];
        [menu alignItemsHorizontallyWithPadding:10];
    }
    
	return self;
}

#pragma mark - Action Methods

- (void) menuItemTouched:(CCMenuItem*)sender{

    [Utility playButtonSound];
    switch (sender.tag) {
        case kEducateEnglishButtonTag:
            selectedLearningType = kLearningTypeEnglish;
            break;
        case kEducateMathsButtonTag:
            selectedLearningType = kLearningTypeMaths;
            break;
        case kEducateArabicButtonTag:
            selectedLearningType = kLearningTypeArabic;
            break;
        case kEducateArabicMathsButtonTag:
            selectedLearningType = kLearningTypeArabicMaths;
            break;            
        default:
            break;
    }
    [[CCDirector sharedDirector]replaceScene:[CCTransitionFade transitionWithDuration:kReplaceSceneDelay scene:[EducateLayer scene]]];
}

- (void) backButtonTouched:(id)sender{
    [Utility playButtonSound];    
    [[CCDirector sharedDirector]replaceScene:[CCTransitionFade transitionWithDuration:kReplaceSceneDelay scene:[MainMenuLayer scene]]];
}

- (void)ccTouchEnded:(UITouch *)touch withEvent:(UIEvent *)event{
    
}

// on "dealloc" you need to release all your retained objects
- (void) dealloc
{
	// in case you have something to dealloc, do it in this method
	// in this particular example nothing needs to be released.
	// cocos2d will automatically release all the children (Label)
	// don't forget to call "super dealloc"
	[super dealloc];
}


-(void) onEnter
{
    // Called right after a node’s init method is called.
    // If using a CCTransitionScene: called when the transition begins.
    [super onEnter];
}

-(void) onEnterTransitionDidFinish
{
}

-(void) onExit
{
    // Called right before node’s dealloc method is called.
    // If using a CCTransitionScene: called when the transition has ended.
    [super onExit];
}


@end
