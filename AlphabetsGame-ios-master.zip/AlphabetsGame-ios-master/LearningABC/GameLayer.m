//
//  GameLayer.m
//  LearningABC
//
//  Created by Faiz Rasool on 6/5/13.
//  Copyright 2013 D-Tech. All rights reserved.
//

#import "GameLayer.h"
#import "HudMenuLayer.h"

@implementation GameLayer
+(CCScene *) scene
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	GameLayer *layer = [GameLayer node];
	
    // add layer as a child to scene
	[scene addChild: layer];
	
	// return the scene
	return scene;
}
/*
 if(i == arc4random() % 4){
 // Add key label
 currentlySelectedAlphabet = [alp retain];
 CCSprite * key = [CCSprite spriteWithFile:currentlySelectedAlphabet.imageName];
 CGSize size = [CCDirector sharedDirector].winSize;
 key.position = ccp(size.width/2, 50);
 [key resizeTo:CGSizeMake(key.boundingBox.size.width/1.5,key.boundingBox.size.height/1.5)];
 [self addChild:key z:0 tag:999];
 [Utility performSelector:@selector(playSoundEffect:) withObject:currentlySelectedAlphabet.soundName afterDelay:0.5];
 }
 */

- (void) addBubbles {
    
    // Remove old key label and empty on screen alphabets array
    CCNode * key = [self getChildByTag:999];
    [self removeChild:key cleanup:YES];
    [onScreenAlphabets removeAllObjects];
    
    for(int i=1; i<=4; i++){
        
        int index = ( (arc4random() % (self.alphabets.count)) );
        Alphabet * alp = [self.alphabets objectAtIndex:index];
        [onScreenAlphabets addObject:alp];
        
        int randomBubbleIndex = ( (arc4random() % (self.bubbles.count)) );
        TouchSprite * monster = [TouchSprite spriteWithFile:[self.bubbles objectAtIndex:randomBubbleIndex]];
        [monster setAlphabet:alp];
        [monster resizeTo:CGSizeMake(monster.contentSize.width/1.5, monster.contentSize.height/1.5)];
        monster.tag = i;
        
        //        CCSprite * bubble = [CCSprite spriteWithFile:[self.bubbles objectAtIndex:randomBubbleIndex]];
        //        [bubble resizeTo:CGSizeMake(bubble.contentSize.width/1.5, bubble.contentSize.height/1.5)];
        CCSprite * letter = [CCSprite spriteWithFile:alp.imageName];
        [letter resizeTo:CGSizeMake(letter.contentSize.width, letter.contentSize.height)];
        letter.position = ccp(monster.contentSize.width/2, monster.contentSize.height/2);
        //  [monster addChild:bubble z:0];
        [monster addChild:letter z:1];
        
        // Determine where to spawn the monster along the X axis
        CGSize winSize = [CCDirector sharedDirector].winSize;
        int minX = monster.boundingBox.size.width;
        int maxX = winSize.width - monster.contentSize.width;
        int rangeX = maxX - minX;
        int actualX = (arc4random() % rangeX);// - minX;
        
        if(actualX < monster.contentSize.width)
            actualX = i * monster.boundingBox.size.width;
        // Create the monster slightly off-screen along the right edge,
        // and along a random position along the Y axis as calculated above
        monster.position = ccp(actualX, - monster.contentSize.width/1.5);
        
        //CCLOG(@"Bubble %d: x= %2.f, y=%2.f",i,monster.position.x,monster.position.y);
        [self addChild:monster z:25];
        
        // Determine speed of the monster
        int minDuration = 5.0;
        int maxDuration = 10.0;
        int rangeDuration = maxDuration - minDuration;
        int actualDuration = (arc4random() % rangeDuration) + minDuration;
        
        // Create the actions
        CCMoveTo * actionMove = [CCMoveTo actionWithDuration:actualDuration
                                                    position:ccp(actualX, winSize.height + monster.contentSize.height + 50)];
        CCCallBlockN * actionMoveDone = [CCCallBlockN actionWithBlock:^(CCNode *node) {
            [node removeFromParentAndCleanup:YES];
        }];
        [monster runAction:[CCSequence actions:actionMove, actionMoveDone, nil]];
    }
    [self chooseKeyLetterAndAddToScene];
}

- (void) chooseKeyLetterAndAddToScene{
    
    int rand = arc4random() % onScreenAlphabets.count;
    // Add key label
    currentlySelectedAlphabet = [[onScreenAlphabets objectAtIndex:rand] retain];
    CCSprite * key = [CCSprite spriteWithFile:currentlySelectedAlphabet.imageName];
    CGSize size = [CCDirector sharedDirector].winSize;
    key.position = ccp(size.width/2, 50);
    [key resizeTo:CGSizeMake(key.boundingBox.size.width/1.5,key.boundingBox.size.height/1.5)];
    [self addChild:key z:0 tag:999];
    [Utility performSelector:@selector(playSoundEffect:) withObject:currentlySelectedAlphabet.soundName afterDelay:0.5];
}

- (void) removeBubblesFromScene{
    //    for(TouchSprite* sprite in self.children){
    //        if([sprite isKindOfClass:[TouchSprite class]]){
    //            if([onScreenAlphabets containsObject:sprite.alphabet]){
    //                [sprite removeFromParentAndCleanup:YES];
    //            }
    //        }
    //    }
    for(int i = 1; i <= 4; i++ ){
        CCNode * child = [self getChildByTag:i];
        [child removeFromParentAndCleanup:YES];
    }
}

- (void) addScoreLabels{
    correctLabel = [CCLabelTTF labelWithString:@"0" fontName:@"MarkerFelt-Wide" fontSize:26.0];
    correctLabel.position = ccp(self.contentSize.width/1.7, self.contentSize.height/5.8);
    correctLabel.color = ccYELLOW;
    [self addChild:correctLabel];
    
    wrongLabel = [CCLabelTTF labelWithString:@"0" fontName:@"MarkerFelt-Wide" fontSize:26.0];
    wrongLabel.position = ccp(self.contentSize.width/2.4, self.contentSize.height/5.8);
    wrongLabel.color = ccYELLOW;
    [self addChild:wrongLabel];
}

// on "init" you need to initialize your instance
-(id) init
{
	// always call "super" init
	// Apple recommends to re-assign "self" with the "super's" return value
	if( (self=[super init]) ) {
        
        // Add notification observer
        [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(receivedCorrectNotification:) name:kCorrectBubbleTappedNotification object:nil];
        
        [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(receivedWrongNotification:) name:kWrongBubbleTappedNotification object:nil];
        
        
        CGSize size = [[CCDirector sharedDirector]winSize];
        CCSprite *background = nil;
        
        NSString * postfix = nil;
        
        switch (selectedGameInterface) {
            case 0:
                postfix = @"_boy.png";
                break;
            case 1:
                postfix = @"_girl.png";
                break;
            default:
                break;
        }
        
        if( UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {
            if(isIphone5)
                background = [CCSprite spriteWithFile:[@"gamescreen_iphone5" stringByAppendingString:postfix]];
            else
                background = [CCSprite spriteWithFile:[@"gamescreen_iphone4" stringByAppendingString:postfix]];
        }
        background.position = ccp(size.width/2, size.height/2);
        [self addChild:background];
        
        [self addButtonsPanelToScene];
        
        // Load alphabets
        self.alphabets = [Utility loadAlphabetsOfType:selectedLearningType];
        self.bubbles = [[NSArray alloc] initWithObjects:@"green_bubble.png",@"blue_bubble.png",@"red_bubble.png",@"yellow_bubble.png",@"dark_bubble.png",@"orange_bubble.png",@"parrot_bubble.png",@"pink_bubble.png",@"skyblue_bubble.png", nil];
        onScreenAlphabets = [[CCArray alloc]init];
        
        //        BubbleSprite * sprite = [BubbleSprite spriteWithFile:@"green_bubble.png"];
        //        sprite.position = ccp(size.width/2, size.height/2);
        //        [self addChild:sprite z:0 tag:1];
        
        if(selectedGameInterface == 0)
            [self addAnimationWithFile:kBoyDefaultFileName numberOfFrames:1];
        else
            [self addAnimationWithFile:kGirlDefaultAnimationFileName numberOfFrames:1];
        
        [self addBubbles];
        [self addScoreLabels];
        [self schedule:@selector(gameLogic:) interval:kScheduleDelay];
        
        [self setTouchEnabled:NO];
    }
	return self;
}


#pragma mark - Notifications

- (void) receivedCorrectNotification:(NSNotification*)notif{
    correctCounter++;
    [correctLabel setString:[NSString stringWithFormat:@"%d",correctCounter]];
    
    
    [self unschedule:@selector(gameLogic:)];
    [self performSelector:@selector(removeBubblesFromScene) withObject:nil afterDelay:0.3];
    
    [self performSelector:@selector(addBubbles) withObject:nil afterDelay:0.8];
    [self schedule:@selector(gameLogic:) interval:kScheduleDelay];
    
    // play animation
    if(selectedGameInterface == 0)
        [self addAnimationWithFile:kBoyHappyAnimationFileName numberOfFrames:8];
    else
        [self addAnimationWithFile:kGirlHappyAnimationFileName numberOfFrames:8];
}

- (void) receivedWrongNotification:(NSNotification*)notif{
    wrongCounter++;
    [wrongLabel setString:[NSString stringWithFormat:@"%d",wrongCounter]];
    // play animation
    if(selectedGameInterface == 0)
        [self addAnimationWithFile:kBoySadAnimationFileName numberOfFrames:6];
    else
        [self addAnimationWithFile:kGirlSadAnimationFileName numberOfFrames:6];
    
    if(wrongCounter == 3){

       CCScene * hudScene = [HudMenuLayer scene];
        [[CCDirector sharedDirector] performSelector:@selector(replaceScene:) withObject:[CCTransitionZoomFlipX transitionWithDuration:kReplaceSceneDelay scene:hudScene] afterDelay:0.5];
         
//         replaceScene:[CCTransitionZoomFlipX transitionWithDuration:kReplaceSceneDelay scene:hudScene]];
    }
    
}

- (void) addButtonsPanelToScene{
    CGSize size = [[CCDirector sharedDirector]winSize];
    
    //    CCMenuItem *soundOnItem = [CCMenuItemImage itemWithNormalImage:@"soundButton.png" selectedImage:@"soundButton.png"];
    //
    //    CCMenuItem *soundOffItem = [CCMenuItemImage itemWithNormalImage:@"mute.png"
    //                                                      selectedImage:@"mute_rollover.png"];
    //    CCMenuItemToggle *soundToggleItem = [CCMenuItemToggle itemWithTarget:self
    //                                                                selector:@selector(panelButtonPressed:)];
    //    soundToggleItem.tag = kSoundButtonTag;
    
    CCMenuItemSprite * soundOn = [CCMenuItemSprite itemWithNormalSprite:[CCSprite spriteWithFile:@"sound.png"] selectedSprite:[CCSprite spriteWithFile:@"sound_rollover.png"] target:self selector:@selector(panelButtonPressed:)];
    
    CCMenuItemSprite * soundOff = [CCMenuItemSprite itemWithNormalSprite:[CCSprite spriteWithFile:@"mute.png"] selectedSprite:[CCSprite spriteWithFile:@"mute_rollover.png"] target:self selector:@selector(panelButtonPressed:)];
    
    CCMenuItemToggle * sound = [CCMenuItemToggle itemWithTarget:self selector:@selector(panelButtonPressed:) items:soundOn, soundOff, nil];
    
    sound.tag = kSoundButtonTag;
    
    CCMenuItemSprite * home = [CCMenuItemSprite itemWithNormalSprite:[CCSprite spriteWithFile:@"home.png"] selectedSprite:[CCSprite spriteWithFile:@"home_rollover.png"] target:self selector:@selector(panelButtonPressed:)];
    home.tag = kHomeButtonTag;
    
    CCMenuItemSprite * learn = [CCMenuItemSprite itemWithNormalSprite:[CCSprite spriteWithFile:@"learnbutton.png"] selectedSprite:[CCSprite spriteWithFile:@"learnbutton_rollover.png"] target:self selector:@selector(panelButtonPressed:)];
    learn.tag = kLearnButtonTag;
    
    CCMenuItemSprite * play = [CCMenuItemSprite itemWithNormalSprite:[CCSprite spriteWithFile:@"play.png"] selectedSprite:[CCSprite spriteWithFile:@"play_rollover.png"] target:self selector:@selector(panelButtonPressed:)];
    CCMenuItemSprite * pause = [CCMenuItemSprite itemWithNormalSprite:[CCSprite spriteWithFile:@"pause.png"] selectedSprite:[CCSprite spriteWithFile:@"pause_rollover.png"] target:self selector:@selector(panelButtonPressed:)];
    CCMenuItemToggle * playPause = [CCMenuItemToggle itemWithTarget:self selector:@selector(panelButtonPressed:) items:play, pause, nil];
    
    playPause.tag = kPlayPauseButtonTag;
    
    CCMenu * panel = [CCMenu menuWithItems:playPause, sound, learn, home, nil];
    panel.position = ccp(size.width/1.378, size.height/1.13);
    [panel alignItemsHorizontallyWithPadding:10.0];
    [self addChild:panel z:0];
}


- (void) panelButtonPressed:(CCMenuItem*)sender{
    switch (sender.tag) {
        case kSoundButtonTag:{
            if([SimpleAudioEngine sharedEngine].isBackgroundMusicPlaying)
                [[SimpleAudioEngine sharedEngine]stopBackgroundMusic];
            else
                [Utility playBackgroundMusic:kBackgroundMusicSound];
            break;
        }
        case kHomeButtonTag:
            [[CCDirector sharedDirector]replaceScene:[CCTransitionFade transitionWithDuration:kReplaceSceneDelay scene:[MainMenuLayer scene]]];
            break;
        case kPlayPauseButtonTag:{
            //            HUDLayer * pause = [[HUDLayer alloc] init];
            //            [pause setStatusString:@"Resume"];
            //            [pause showRestartMenu:YES];
            //            return;
            if([[CCDirector sharedDirector] isPaused])
                [[CCDirector sharedDirector]resume];
            else
                [[CCDirector sharedDirector]pause];
            
            break;
        }
        case kLearnButtonTag:
            [[CCDirector sharedDirector]replaceScene:[CCTransitionFade transitionWithDuration:kReplaceSceneDelay scene:[EducateMenuLayer scene]]];
            break;
        default:
            break;
    }
}
/*
 -(void) registerWithTouchDispatcher
 {
 [[[CCDirector sharedDirector] touchDispatcher] addTargetedDelegate:self priority:0 swallowsTouches:YES];
 }
 
 - (BOOL)ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event {
 return YES;
 }
 
 - (void)ccTouchEnded:(UITouch *)touch withEvent:(UIEvent *)event {
 CGPoint location = [self convertTouchToNodeSpace: touch];
 
 BubbleSprite * cocosGuy = (BubbleSprite*) [self getChildByTag:1];
 [cocosGuy stopAllActions];
 [cocosGuy runAction: [CCMoveTo actionWithDuration:1 position:location]];
 
 }
 */
-(void)gameLogic:(ccTime)dt {
    [self addBubbles];
}

//- (void)scheduleUpdate{
//    [self schedule:@selector(addBubbleToGameScene:) interval:4];
//}

//
//- (void) addBubbleToGameScene:(ccTime)delta{
//    CGSize size = [[CCDirector sharedDirector]winSize];
//    BubbleSprite * sprite = [BubbleSprite spriteWithFile:@"A.png"];
//    sprite.position = ccp(size.width/2, size.height/2);
//    [self addChild:sprite];
//    CGPoint pos = sprite.position;
//    [sprite runAction:[CCMoveBy actionWithDuration:2]];
//    sprite.position = pos;
//}

//- (void)ccTouchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
//
//}

- (void) addAnimationWithFile:(NSString*)imageName numberOfFrames:(int)frameCount{
    CGSize s = [[CCDirector sharedDirector] winSize];
    // IMPORTANT:
    // The sprite frames will be cached AND RETAINED, and they won't be released unless you call
    //     [[CCSpriteFrameCache sharedSpriteFrameCache] removeUnusedSpriteFrames];
    //NOTE:
    //The name of your .png and .plist must be the same name
    
    CCNode * node = [self getChildByTag:321];
    [self removeChild:node];
    
    NSString * plistFile = [NSString stringWithFormat:@"%@.plist",imageName];
    NSString * imageFileName = [NSString stringWithFormat:@"%@.png",imageName];
    [[CCSpriteFrameCache sharedSpriteFrameCache] addSpriteFramesWithFile:plistFile];
    //
    // Animation using Sprite Sheet
    //
    sprite = [CCSprite spriteWithSpriteFrameName:[NSString stringWithFormat:@"%@_%d.png",imageName,1]]; //"grossini_dance_01.png" comes from your .plist file
    sprite.position = ccp( s.width/7, s.height/4);
    
    batchNode = [CCSpriteBatchNode batchNodeWithFile:imageFileName];
    [batchNode addChild:sprite];
    batchNode.tag = 321;
    [self addChild:batchNode];
    
    
    animFrames = [NSMutableArray array];
    for(int i = 1; i < frameCount; i++) {
        CCSpriteFrame *frame = [[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:[NSString stringWithFormat:@"%@_%d.png",imageName,i]];
        [animFrames addObject:frame];
    }
    animation = [CCAnimation animationWithSpriteFrames:animFrames delay:0.3f];
    [sprite runAction:[CCAnimate actionWithAnimation:animation]];
}

// on "dealloc" you need to release all your retained objects
- (void) dealloc
{
	// in case you have something to dealloc, do it in this method
	// in this particular example nothing needs to be released.
	// cocos2d will automatically release all the children (Label)
	// don't forget to call "super dealloc"
    [[CCSpriteFrameCache sharedSpriteFrameCache] removeUnusedSpriteFrames];
    [onScreenAlphabets release];
    
    [_alphabets release];
    [_bubbles release];
	[super dealloc];
}

-(void) onEnter
{
    // Called right after a node’s init method is called.
    // If using a CCTransitionScene: called when the transition begins.
    [super onEnter];
}

-(void) onEnterTransitionDidFinish
{
}

-(void) onExit
{
    // Called right before node’s dealloc method is called.
    // If using a CCTransitionScene: called when the transition has ended.
    [[NSNotificationCenter defaultCenter]removeObserver:self name:kCorrectBubbleTappedNotification object:nil];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:kWrongBubbleTappedNotification object:nil];
    
    [super onExit];
}


@end
