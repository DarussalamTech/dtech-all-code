//
//  TouchSprite.m
//  Touching Sprites
//
//  Created by Faiz Rasool on 6/19/13.
//  Copyright 2013 D-Tech. All rights reserved.
//

#import "TouchSprite.h"


@implementation TouchSprite

-(id)initWithKey:(int)key {
    if((self = [super initWithFile:[NSString stringWithFormat:@"key_%i.png",key]])) {
        
    }
    return self;
}

- (id)initWithTexture:(CCTexture2D *)texture{
    self = [super initWithTexture:texture];
    if (self) {
        
    }
    return self;
}
//
//- (id)initWithFile:(NSString *)filename{
//    self = [super initWithFile:filename];
//    if(self){
//        
//    }
//    return self;
//}

-(BOOL) tsTouchBegan:(UITouch*)touch withEvent: (UIEvent*)event {
    //NSLog( @"tsTouchBegan");
    [self pauseSchedulerAndActions];
    return YES;
}
-(void) tsTouchMoved:(UITouch*)touch withEvent: (UIEvent*)event {
    //NSLog( @"tsTouchMoved");
    
}
-(void) tsTouchEnded:(UITouch*)touch withEvent: (UIEvent*)event {
//    NSLog( @"tsTouchEnded on sprite with tag %d",self.tag);
    [self resumeSchedulerAndActions];
    
    if(self.alphabet == currentlySelectedAlphabet){
        [self performSelector:@selector(removeAllChildrenWithCleanup:) withObject:[NSNumber numberWithBool:YES] afterDelay:0.1];
        [self performSelector:@selector(removeFromParentAndCleanup:) withObject:[NSNumber numberWithBool:YES] afterDelay:0.3];
        CCFadeOut * fade = [CCFadeOut actionWithDuration:0.3];
        [self runAction:fade];
        [Utility playSoundEffect:@"explosion-01.wav"];
        [[NSNotificationCenter defaultCenter]postNotificationName:kCorrectBubbleTappedNotification object:nil];
    }
    else{
        CCBlink * blink = [CCBlink actionWithDuration:0.5 blinks:3];
        [self runAction:blink];
        [Utility playSoundEffect:@"test.caf"];
        [[NSNotificationCenter defaultCenter]postNotificationName:kWrongBubbleTappedNotification object:nil];
    }
}
-(void) tsTouchCancelled:(UITouch*)touch withEvent: (UIEvent*)event {
//    NSLog( @"tsTouchCancelled");
}

//
// Utilities. Don't override these unless you really need to.
//

-(CGRect) rect {
    CGSize s = [self.texture contentSize];
    return CGRectMake(-s.width / 2, -s.height / 2, s.width, s.height);
}

-(BOOL) didTouch: (UITouch*)touch {
    return CGRectContainsPoint( [self rect], [self convertTouchToNodeSpaceAR: touch] );
}

-(void)resizeTo:(CGSize) theSize
{
    CGFloat newWidth = theSize.width;
    CGFloat newHeight = theSize.height;
    
    
    float startWidth = self.contentSize.width;
    float startHeight = self.contentSize.height;
    
    float newScaleX = newWidth/startWidth;
    float newScaleY = newHeight/startHeight;
    
    self.scaleX = newScaleX;
    self.scaleY = newScaleY;
    
}

//
// The actual touch listener functions. Don't override these either.
//

-(BOOL) ccTouchBegan:(UITouch*)touch withEvent: (UIEvent*)event {
//    NSLog(@"attempting touch.");
    if([self didTouch: touch]) {
        return [self tsTouchBegan:touch withEvent: event];
    }
    return NO;
}

-(void) ccTouchMoved:(UITouch*)touch withEvent: (UIEvent*)event {
    if([self didTouch:touch])
        [self tsTouchMoved:touch withEvent:event];
}

-(void) ccTouchEnded:(UITouch*)touch withEvent: (UIEvent*)event {
    if([self didTouch:touch])
        [self tsTouchEnded:touch withEvent:event];
}

-(void) ccTouchCancelled:(UITouch*)touch withEvent: (UIEvent*)event {
    if([self didTouch:touch])
        [self tsTouchCancelled:touch withEvent:event];
}

-(void) onEnter
{
    [super onEnter];
    [[[CCDirector sharedDirector]touchDispatcher] addTargetedDelegate:self priority:INT_MIN+1 swallowsTouches:YES];
}

-(void) dealloc
{
    [_alphabet release];
    [[[CCDirector sharedDirector]touchDispatcher] removeDelegate:self];
    [super dealloc];
}

@end