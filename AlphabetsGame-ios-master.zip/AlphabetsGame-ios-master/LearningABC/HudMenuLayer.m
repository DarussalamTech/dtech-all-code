//
//  MainMenuLayer.m
//  LearningABC
//
//  Created by Faiz Rasool on 5/30/13.
//  Copyright 2013 D-Tech. All rights reserved.
//

#import "HudMenuLayer.h"
#import "GameLayer.h"

@implementation HudMenuLayer
// Helper class method that creates a Scene with the HelloWorldLayer as the only child.
+(CCScene *) scene
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	HudMenuLayer *layer = [HudMenuLayer node];
	
	// add layer as a child to scene
	[scene addChild: layer];
	
	// return the scene
	return scene;
}

// on "init" you need to initialize your instance
-(id) init
{    
	// always call "super" init
	// Apple recommends to re-assign "self" with the "super's" return value
	if( (self=[super init]) ) {
        
        CGSize winSize = [CCDirector sharedDirector].winSize;
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
            _statusLabel = [CCLabelBMFont labelWithString:@"" fntFile:@"Arial-hd.fnt"];
        } else {
            _statusLabel = [CCLabelBMFont labelWithString:@"" fntFile:@"Arial.fnt"];
        }
        _statusLabel.position = ccp(winSize.width* 0.85, winSize.height * 0.9);
        [self addChild:_statusLabel];
        
        
        NSString * message = @"Game Over!";
        
        CCLabelBMFont *label;
    //    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
            label = [CCLabelBMFont labelWithString:message fntFile:@"Arial-hd.fnt"];
    //    } else {
      //      label = [CCLabelBMFont labelWithString:message fntFile:@"Arial.fnt"];
      //  }
        label.scale = 0.1;
        label.position = ccp(winSize.width/2, winSize.height * 0.6);
        [self addChild:label];
        
        CCLabelBMFont *restartLabel;
    //    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
            restartLabel = [CCLabelBMFont labelWithString:@"Restart" fntFile:@"Arial-hd.fnt"];
     //   } else {
       //     restartLabel = [CCLabelBMFont labelWithString:@"Restart" fntFile:@"Arial.fnt"];
       // }
        
        CCMenuItemLabel *restartItem = [CCMenuItemLabel itemWithLabel:restartLabel target:self selector:@selector(restartTapped:)];
        restartItem.scale = 0.1;
        restartItem.position = ccp(winSize.width/2, winSize.height * 0.4);
        
        CCLabelBMFont *mainMenuLabel;
        mainMenuLabel = [CCLabelBMFont labelWithString:@"Main Menu" fntFile:@"Arial-hd.fnt"];
        
        CCMenuItemLabel *menuItem = [CCMenuItemLabel itemWithLabel:mainMenuLabel target:self selector:@selector(mainMenuTapped:)];
      //  menuItem.scale = 0.1;
        menuItem.position = ccp(winSize.width/2, winSize.height * 0.2);
        
        
        CCMenu *menu = [CCMenu menuWithItems:restartItem,menuItem, nil];
        menu.position = CGPointZero;
        [self addChild:menu z:10];
        
        [restartItem runAction:[CCScaleTo actionWithDuration:0.5 scale:1.0]];
        [label runAction:[CCScaleTo actionWithDuration:0.5 scale:1.0]];
    }
	return self;
}

- (void)restartTapped:(id)sender {
    
    // Reload the current scene
    CCScene *scene = [GameLayer scene];
    [[CCDirector sharedDirector] replaceScene:[CCTransitionZoomFlipX transitionWithDuration:kReplaceSceneDelay scene:scene]];
}
- (void)mainMenuTapped:(id)sender {
    
    // Reload the current scene
    CCScene *scene = [MainMenuLayer scene];
    [[CCDirector sharedDirector] replaceScene:[CCTransitionZoomFlipX transitionWithDuration:kReplaceSceneDelay scene:scene]];
}


// on "dealloc" you need to release all your retained objects
- (void) dealloc
{
	// in case you have something to dealloc, do it in this method
	// in this particular example nothing needs to be released.
	// cocos2d will automatically release all the children (Label)
	// don't forget to call "super dealloc"
	[super dealloc];
}

-(void) onEnter
{
    // Called right after a node’s init method is called.
    // If using a CCTransitionScene: called when the transition begins.
    [super onEnter];
}

-(void) onEnterTransitionDidFinish
{
}

-(void) onExit
{
    // Called right before node’s dealloc method is called.
    // If using a CCTransitionScene: called when the transition has ended.
    [super onExit];
}


@end
