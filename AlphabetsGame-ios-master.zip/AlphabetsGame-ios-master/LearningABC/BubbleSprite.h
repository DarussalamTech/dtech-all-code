//
//  BubbleSprite.h
//  LearningABC
//
//  Created by Faiz Rasool on 6/11/13.
//  Copyright 2013 D-Tech. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"


typedef enum tagButtonState {
    kButtonStatePressed,
    kButtonStateNotPressed
} ButtonState;

typedef enum tagButtonStatus {
    kButtonStatusEnabled,
    kButtonStatusDisabled
} ButtonStatus;

@interface BubbleSprite : CCSprite <CCTouchOneByOneDelegate> {
@private
    ButtonState state;
    CCTexture2D *buttonNormal;
    CCTexture2D *buttonLit;
    ButtonStatus buttonStatus;
}

@property(nonatomic, readonly) CGRect rect;

+ (id)spuButtonWithTexture:(CCTexture2D *)normalTexture;

- (void)setNormalTexture:(CCTexture2D *)normalTexture;
- (void)setLitTexture:(CCTexture2D *)litTexture;
- (BOOL)isPressed;
- (BOOL)isNotPressed;
-(void)resizeTo:(CGSize) theSize;

@end