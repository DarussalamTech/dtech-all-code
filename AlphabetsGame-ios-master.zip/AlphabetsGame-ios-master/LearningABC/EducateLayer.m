//
//  EducateMenuLayer.m
//  LearningABC
//
//  Created by Faiz Rasool on 5/31/13.
//  Copyright 2013 D-Tech. All rights reserved.
//

#import "EducateLayer.h"
#import "CCMenu+Layout.h"

@implementation EducateLayer

+(CCScene *) scene
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	EducateLayer *layer = [EducateLayer node];
	
	// add layer as a child to scene
	[scene addChild: layer];
    
	// return the scene
	return scene;
}

// on "init" you need to initialize your instance
-(id) init
{
	// always call "super" init
	// Apple recommends to re-assign "self" with the "super's" return value
	if( (self=[super init]) ) {
        CGSize size = [[CCDirector sharedDirector]winSize];
        [self setTouchEnabled:YES];
        
        // background image
        
        CCSprite *background = nil;
        
        NSString * postfix = nil;
        
        switch (selectedGameInterface) {
            case 0:
                postfix = @"_boy.png";
                break;
            case 1:
                postfix = @"_girl.png";
                break;
            default:
                break;
        }
        
        if( UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {
            if(isIphone5)
                background = [CCSprite spriteWithFile:[@"learn_iphone5" stringByAppendingString:postfix]];
            else
                background = [CCSprite spriteWithFile:[@"learn_iphone4" stringByAppendingString:postfix]];
        }

        
        background.position = ccp(size.width/2, size.height/2);
        [self addChild:background];
        
        currentIndex = 0;
        self.alphs = [[Utility loadAlphabetsOfType:selectedLearningType] retain];
        
//        CCMenuItemFont * back = [CCMenuItemFont itemWithString:@"Back" target:self selector:@selector(backButtonTouched:)];
//        CCMenu * bMenu = [CCMenu menuWithItems:back, nil];
//        
//        bMenu.position = ccp(30, size.height - 20);
//        
//        [self addChild:bMenu];
        
        // Add sprite for the very first time
        [self performSelector:@selector(addSpriteAtLoad) withObject:nil afterDelay:1.0];
        
        // Next button
        CCMenuItemSprite * next = [CCMenuItemSprite itemWithNormalSprite:[CCSprite spriteWithFile:@"rightArrow.png"] selectedSprite:[CCSprite spriteWithFile:@"rightArrow.png"] target:self selector:@selector(nextButtonTapped:)];
        CCMenu * nMenu = [CCMenu menuWithItems:next, nil];
        
        nMenu.position = ccp(size.width/1.16  , size.height/1.9);
        
        [self addChild:nMenu z:0 tag:111];

        
        // Next button
        CCMenuItemFont * previous = [CCMenuItemSprite itemWithNormalSprite:[CCSprite spriteWithFile:@"leftArrow.png"] selectedSprite:[CCSprite spriteWithFile:@"leftArrow.png"] target:self selector:@selector(previousButtonTapped:)];
        CCMenu * pMenu = [CCMenu menuWithItems:previous, nil];
        
        pMenu.position = ccp(70  , size.height/1.9);
        
        [self addChild:pMenu z:0 tag:555];
        
        [self addButtonsPanelToScene];
        
        // Add Alphabets to the scene
        [self initAlphabets];
        
    }
	return self;
}

- (void) addButtonsPanelToScene{
    CGSize size = [[CCDirector sharedDirector]winSize];
    
//    CCMenuItem *soundOnItem = [CCMenuItemImage itemWithNormalImage:@"soundButton.png" selectedImage:@"soundButton.png"];
//    
//    CCMenuItem *soundOffItem = [CCMenuItemImage itemWithNormalImage:@"mute.png"
//                                                      selectedImage:@"mute_rollover.png"];
//    CCMenuItemToggle *soundToggleItem = [CCMenuItemToggle itemWithTarget:self
//                                                                selector:@selector(panelButtonPressed:)];
//    soundToggleItem.tag = kSoundButtonTag;
    
    CCMenuItemSprite * soundOn = [CCMenuItemSprite itemWithNormalSprite:[CCSprite spriteWithFile:@"sound.png"] selectedSprite:[CCSprite spriteWithFile:@"sound_rollover.png"] target:self selector:@selector(panelButtonPressed:)];
    
    CCMenuItemSprite * soundOff = [CCMenuItemSprite itemWithNormalSprite:[CCSprite spriteWithFile:@"mute.png"] selectedSprite:[CCSprite spriteWithFile:@"mute_rollover.png"] target:self selector:@selector(panelButtonPressed:)];
    
    CCMenuItemToggle * sound = [CCMenuItemToggle itemWithTarget:self selector:@selector(panelButtonPressed:) items:soundOn, soundOff, nil];
    
    sound.tag = kSoundButtonTag;
    
    CCMenuItemSprite * home = [CCMenuItemSprite itemWithNormalSprite:[CCSprite spriteWithFile:@"home.png"] selectedSprite:[CCSprite spriteWithFile:@"home_rollover.png"] target:self selector:@selector(panelButtonPressed:)];
    home.tag = kHomeButtonTag;
    
    CCMenuItemSprite * learn = [CCMenuItemSprite itemWithNormalSprite:[CCSprite spriteWithFile:@"game.png"] selectedSprite:[CCSprite spriteWithFile:@"game_rollover.png"] target:self selector:@selector(panelButtonPressed:)];
    learn.tag = kGameButtonTag;
    
    CCMenuItemSprite * play = [CCMenuItemSprite itemWithNormalSprite:[CCSprite spriteWithFile:@"play.png"] selectedSprite:[CCSprite spriteWithFile:@"play_rollover.png"] target:self selector:@selector(panelButtonPressed:)];

    play.tag = kPlaySoundButtonTag;
    
    CCMenu * panel = [CCMenu menuWithItems:play, sound, learn, home, nil];
    panel.position = ccp(size.width/1.378, size.height/1.13);
    [panel alignItemsHorizontallyWithPadding:10.0];
    [self addChild:panel];
}

- (void) addSpriteAtLoad{
    CGSize size = [[CCDirector sharedDirector]winSize];
    Alphabet * alph = nil;
    if(self.alphs.count > 0)
        alph = [self.alphs objectAtIndex:currentIndex];
    currentAlphabet = alph;
    alphabetSprite = [CCSprite spriteWithFile:alph.imageName];
    if(isDeviceIphone)
        [alphabetSprite resizeTo:CGSizeMake(alphabetSprite.boundingBox.size.width * 2, size.height/2)];
    else
        [alphabetSprite resizeTo:CGSizeMake(size.width/8, size.height/4)];
    
    alphabetSprite.position = CGPointMake(size.width/2, size.height/2);
    [self addChild:alphabetSprite];
    [Utility playSoundEffect:alph.soundName];
}

- (void) nextButtonTapped:(CCMenuItem*)sender{
//    [SimpleAudioEngine sharedEngine].mute = YES;
//    CCLOG(@"alphabets count = %d",alphabets.count);
    if(currentIndex == self.alphs.count - 1){
        CCMenu * menu = (id)[self getChildByTag:111];
        menu.enabled = NO;
        
        return;
    }
    else{
        CCMenu * menu = (id)[self getChildByTag:111];
        menu.enabled = YES;
        
        CCMenu * back = (id)[self getChildByTag:555];
        back.enabled = YES;
    }
    // remove old sprite and add new
    [alphabetSprite removeFromParentAndCleanup:YES];

    currentIndex++;
    
    CGSize size = [[CCDirector sharedDirector]winSize];
    Alphabet * alph = nil;
    if(self.alphs.count > 0)
        alph = [self.alphs objectAtIndex:currentIndex];
    currentAlphabet = alph;
    alphabetSprite = [CCSprite spriteWithFile:alph.imageName];
    
    if(isDeviceIphone)
        [alphabetSprite resizeTo:CGSizeMake(alphabetSprite.boundingBox.size.width * 2, size.height/2)];
    else
        [alphabetSprite resizeTo:CGSizeMake(size.width/8, size.height/4)];
    alphabetSprite.position = CGPointMake(size.width/2, size.height/2);
    [self addChild:alphabetSprite];
    
    [Utility playSoundEffect:alph.soundName];
}

#pragma mark -

- (void) panelButtonPressed:(CCMenuItem*)sender{
    switch (sender.tag) {
        case kSoundButtonTag:{
            if([SimpleAudioEngine sharedEngine].isBackgroundMusicPlaying)
                [[SimpleAudioEngine sharedEngine]stopBackgroundMusic];
            else
                [Utility playBackgroundMusic:kBackgroundMusicSound];
            break;
        }
        case kHomeButtonTag:
            [[CCDirector sharedDirector]replaceScene:[CCTransitionFade transitionWithDuration:kReplaceSceneDelay scene:[MainMenuLayer scene]]];
            break;
        case kPlaySoundButtonTag:
            [Utility playSoundEffect:currentAlphabet.soundName];
            break;
        case kGameButtonTag:
            [[CCDirector sharedDirector]replaceScene:[CCTransitionFade transitionWithDuration:kReplaceSceneDelay scene:[GameMenuLayer scene]]];
            break;
        default:
            break;
    }
}

- (void) previousButtonTapped:(CCMenu*)sender{
//    [SimpleAudioEngine sharedEngine].mute = YES;
    //    CCLOG(@"alphabets count = %d",alphabets.count);
    if(currentIndex == 0){
        CCMenu * menu = (id)[self getChildByTag:555];
        menu.enabled = NO;
        
        CCMenu * next = (id)[self getChildByTag:111];
        next.enabled = YES;
        return;
    }
    else{
        CCMenu * menu = (id)[self getChildByTag:555];
        menu.enabled = YES;
        
        CCMenu * nxt = (id)[self getChildByTag:111];
        nxt.enabled = YES;
    }
    // remove old sprite and add new
    [alphabetSprite removeFromParentAndCleanup:YES];
    
    currentIndex--;
    
    CGSize size = [[CCDirector sharedDirector]winSize];
    Alphabet * alph = nil;
    if(self.alphs.count > 0)
        alph = [self.alphs objectAtIndex:currentIndex];
    currentAlphabet = alph;
    alphabetSprite = [CCSprite spriteWithFile:alph.imageName];
    
    if(isDeviceIphone)
        [alphabetSprite resizeTo:CGSizeMake(alphabetSprite.boundingBox.size.width * 2, size.height/2)];
    else
        [alphabetSprite resizeTo:CGSizeMake(size.width/8, size.height/4)];
    alphabetSprite.position = CGPointMake(size.width/2, size.height/2);
    [self addChild:alphabetSprite];
    
    [Utility playSoundEffect:alph.soundName];
}

- (void) initAlphabets{
    CGSize screenSize = [[CCDirector sharedDirector] winSize];
    // using a temporary sprite is the easiest way to get the image's size
    CCSprite* tempAlphabet = [CCSprite spriteWithFile:@"B.png"];
    float imageWidth = [tempAlphabet texture].contentSize.width;
    // Use as many alphabets as can fit next to each other over the whole screen width.
    
    int numAlphabets = screenSize.width / imageWidth;
    // Initialize the alphabets array using alloc.
    alphabets = [[NSMutableArray alloc] initWithCapacity:numAlphabets];
    for (int i = 0; i < numAlphabets; i++)
    {
        CCSprite* alphabet = [CCSprite spriteWithFile:@"A.png"];
        CCSprite* tempAlphabet = [CCSprite spriteWithFile:@"B.png"];
        //        [self addChild:alphabet z:0 tag:2];
        CCMenuItemSprite * item = [CCMenuItemSprite itemWithNormalSprite:alphabet selectedSprite:tempAlphabet target:self selector:@selector(resetAlphabets)];
        // Also add the spider to the spiders array.
        [alphabets addObject:item];
    }
    CCLOG(@"Total items in array: %d",alphabets.count);
    CCMenu * menu = [CCMenu menuWithArray:alphabets];
    [menu alignItemsInGridWithPadding:ccp(screenSize.width/12,20.0) columns:5];
    menu.position =ccp(20.0f,20.0f);
    // call the method to reposition all spiders
    // [self resetAlphabets];
}

- (void) resetAlphabets{
    CGSize screenSize = [[CCDirector sharedDirector] winSize];
    // Get any spider to get its image width
    CCSprite* tempAlphabet = [alphabets lastObject];
    CGSize size = [tempAlphabet texture].contentSize;
    int numAlphabets = [alphabets count];
    for (int i = 0; i < numAlphabets; i++)
    {
        // Put each spider at its designated position outside the screen
        CCSprite* alphabet = [alphabets objectAtIndex:i];
        CGPoint point = CGPointMake(size.width * i  ,
                                    screenSize.height * 0.5);
        alphabet.position = point;
        [self addChild:alphabet];
        [alphabet stopAllActions];
    }
}

- (void) backButtonTouched:(id)sender{
    [Utility playButtonSound];
    [[CCDirector sharedDirector]replaceScene:[CCTransitionFade transitionWithDuration:kReplaceSceneDelay scene:[EducateMenuLayer scene]]];
}

#pragma mark - Handling Touches

- (void)registerWithTouchDispatcher {
    [[[CCDirector sharedDirector] touchDispatcher] addTargetedDelegate:self priority:0 swallowsTouches:YES];
}

- (BOOL)ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event{
    return YES;
}

- (void)ccTouchMoved:(UITouch *)touch withEvent:(UIEvent *)event{
    
}

- (void)ccTouchEnded:(UITouch *)touch withEvent:(UIEvent *)event{
    id view = touch.view;
    if([view isKindOfClass:[CCSprite class]])
        CCLOG(@"Back Button Tapped");
    ccDrawSolidCircle(ccp(100, 100), 100, 5);
}

// on "dealloc" you need to release all your retained objects
- (void) dealloc
{
	// in case you have something to dealloc, do it in this method
	// in this particular example nothing needs to be released.
	// cocos2d will automatically release all the children (Label)
	// don't forget to call "super dealloc"
	[super dealloc];
}


-(void) onEnter
{
    // Called right after a node’s init method is called.
    // If using a CCTransitionScene: called when the transition begins.
    [alphabets release];
    [alphabetSprite release];
    [currentAlphabet release];
    [super onEnter];
}

-(void) onEnterTransitionDidFinish
{
    
}

-(void) onExit
{
    // Called right before node’s dealloc method is called.
    // If using a CCTransitionScene: called when the transition has ended.
    [super onExit];
}

@end
