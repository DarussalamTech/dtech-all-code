//
//  MainMenuLayer.m
//  LearningABC
//
//  Created by Faiz Rasool on 5/30/13.
//  Copyright 2013 D-Tech. All rights reserved.
//

#import "SelectInterfaceLayer.h"

@implementation SelectInterfaceLayer
// Helper class method that creates a Scene with the HelloWorldLayer as the only child.
+(CCScene *) scene
{    
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	SelectInterfaceLayer *layer = [SelectInterfaceLayer node];
	
	// add layer as a child to scene
	[scene addChild: layer];
	
	// return the scene
	return scene;
}

// on "init" you need to initialize your instance
-(id) init
{
	// always call "super" init
	// Apple recommends to re-assign "self" with the "super's" return value
	if( (self=[super init]) ) {
        
        [self setupInterface];
        
    }
	return self;
}

- (void) setupInterface{
    
    CGSize size = [[CCDirector sharedDirector] winSize];
    
    CCSprite *background = nil;
    
    if( UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {
        if(isIphone5)
            background = [CCSprite spriteWithFile:@"setting_interface_iphone5.png"];
        else
            background = [CCSprite spriteWithFile:@"setting_interface_iphone4.png"];
        }

    background.position = ccp(size.width/2, size.height/2);

    [self addChild:background];
    
    // create a menu item using existing sprites
    CCSprite* normal = [CCSprite spriteWithFile:@"boy.png"];
    CCSprite* selected = [CCSprite spriteWithFile:@"boy-rollover.png"];
    CCMenuItemSprite* item2 = [CCMenuItemSprite
                               itemWithNormalSprite:normal
                               selectedSprite:selected
                               target:self
                               selector:@selector(menuItemTouched:)];
    //item2.position = ccp(size.width/2, size.height/2);
    item2.tag = 0;
    
    // create a menu item using existing sprites
    CCSprite* normal2 = [CCSprite spriteWithFile:@"girl.png"];
    CCSprite* selected2 = [CCSprite spriteWithFile:@"girl-rollover.png"];
    CCMenuItemSprite* item4 = [CCMenuItemSprite
                               itemWithNormalSprite:normal2
                               selectedSprite:selected2
                               target:self
                               selector:@selector(menuItemTouched:)];
    item4.tag = 1;
    
    // create the menu using the items
    CCMenu* menu = [CCMenu menuWithItems:item4, item2 ,nil];
    [menu setPosition:ccp(size.width/2 + 20, size.height/2 - 45)];
    [self addChild:menu];
    // aligning is important, so the menu items don't occupy the same location
    [menu alignItemsHorizontallyWithPadding:40];
}


//- (void)draw{
//    CGSize size = [[CCDirector sharedDirector]winSize];
//    glColor4f(255, 255, 255, 255);
//    CGPoint center = ccp(size.width/2, size.height/2);
//    CGFloat radius = 100.f;
//    CGFloat angle = 360.f;
//    NSInteger segments = 10;
//    BOOL drawLineToCenter = YES;
//
//    ccDrawCircle(center, radius, angle, segments, drawLineToCenter);
//}

- (void) menuItemTouched:(CCMenuItem*)sender{
    
    selectedGameInterface = sender.tag;
    [Utility playButtonSound];
    [[CCDirector sharedDirector]replaceScene:[CCTransitionFade transitionWithDuration:kReplaceSceneDelay scene:[MainMenuLayer scene]]];
}



// on "dealloc" you need to release all your retained objects
- (void) dealloc
{
	// in case you have something to dealloc, do it in this method
	// in this particular example nothing needs to be released.
	// cocos2d will automatically release all the children (Label)
	// don't forget to call "super dealloc"
	[super dealloc];
}

-(void) onEnter
{
    // Called right after a node’s init method is called.
    // If using a CCTransitionScene: called when the transition begins.
    [super onEnter];
}

-(void) onEnterTransitionDidFinish
{
}

-(void) onExit
{
    // Called right before node’s dealloc method is called.
    // If using a CCTransitionScene: called when the transition has ended.
    [super onExit];
}


@end
