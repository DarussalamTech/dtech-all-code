//
//  DTNavigationController.h
//  EnjoyYourLife
//
//  Created by Faiz Rasool on 4/8/13.
//  Copyright (c) 2013 Darussalam Publications. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DTNavigationController : UINavigationController

@end
