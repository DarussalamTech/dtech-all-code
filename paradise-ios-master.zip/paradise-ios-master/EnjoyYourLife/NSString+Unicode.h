//
//  NSString+Unicode.h
//  CaptnCrunch
//
//  Created by Faiz Rasool on 2/28/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Unicode)
- (NSString*) stringToUnicode;
- (NSString*) unicodeToString;
@end
