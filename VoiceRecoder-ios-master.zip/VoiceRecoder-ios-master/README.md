VoiceRecoder
============
