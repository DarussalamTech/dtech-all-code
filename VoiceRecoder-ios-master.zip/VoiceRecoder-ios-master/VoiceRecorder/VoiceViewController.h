//
//  VoiceViewController.h
//  VoiceRecorder
//
//  Created by ahadnawaz on 05/06/2013.
//  Copyright (c) 2013 ahadnawaz. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

@interface VoiceViewController : UIViewController <AVAudioRecorderDelegate>
- (IBAction)recordSound:(id)sender;
@property (strong, nonatomic) IBOutlet UILabel *statusLabel;

@end
