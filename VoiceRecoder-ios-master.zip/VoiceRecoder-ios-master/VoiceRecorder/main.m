//
//  main.m
//  VoiceRecorder
//
//  Created by ahadnawaz on 05/06/2013.
//  Copyright (c) 2013 ahadnawaz. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "VoiceAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([VoiceAppDelegate class]));
    }
}
