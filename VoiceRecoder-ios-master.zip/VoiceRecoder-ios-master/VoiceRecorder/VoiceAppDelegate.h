//
//  VoiceAppDelegate.h
//  VoiceRecorder
//
//  Created by ahadnawaz on 05/06/2013.
//  Copyright (c) 2013 ahadnawaz. All rights reserved.
//

#import <UIKit/UIKit.h>

@class VoiceViewController;

@interface VoiceAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) VoiceViewController *viewController;

@end
