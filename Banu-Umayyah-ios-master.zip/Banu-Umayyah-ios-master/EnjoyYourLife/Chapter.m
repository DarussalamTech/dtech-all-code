//
//  Chapter.m
//  TestCoreText
//
//  Created by ahadnawaz on 14/03/2013.
//  Copyright (c) 2013 ahadnawaz. All rights reserved.
//

#import "Chapter.h"

@implementation Chapter

@end
