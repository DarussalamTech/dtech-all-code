//inside CTColumnView.h

#import <UIKit/UIKit.h>
#import <CoreText/CoreText.h>

@interface CTColumnView : UIView {
    id ctFrame;
}

-(void)setCTFrame:(id)f;

@end
