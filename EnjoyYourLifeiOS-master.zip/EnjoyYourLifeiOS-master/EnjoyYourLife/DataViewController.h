//
//  DataViewController.h
//  CoreTextBasics
//
//  Created by Faiz Rasool on 3/8/13.
//  Copyright (c) 2013 Darussalam Publications. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreText/CoreText.h>
#import <CoreFoundation/CoreFoundation.h>
#import <QuartzCore/QuartzCore.h>
#import "DrawView.h"

@interface DataViewController : UIViewController

@property (strong, nonatomic) UILongPressGestureRecognizer * longPressGestureRecognizer;
@property (strong, nonatomic) IBOutlet UILabel *dataLabel;
@property (strong, nonatomic) id dataObject;

@end
