//
//  coreViewController.m
//  TestCoreText
//
//  Created by ahadnawaz on 08/03/2013.
//  Copyright (c) 2013 ahadnawaz. All rights reserved.
//

#import "coreViewController.h"
#import "TOCViewController.h"
#import "NSString+Unicode.h"
#import "CustomView.h"


@interface coreViewController ()

@end

@implementation coreViewController
CustomView *cstmView ;

-(id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self=[super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        //    self.navigationController.title=@"CoreText";
        self.title =@"Enjoy Your Life";
        self.navigationItem.leftBarButtonItem = nil;
        UIBarButtonItem *contents=[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemBookmarks target:self action:@selector(showContent:)];
              self.navigationItem.rightBarButtonItem=contents;
        
        UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc]
                                              initWithTarget:self action:@selector(hideShowNavBar:)];
        [self.view addGestureRecognizer:tapGesture];
//        UISwipeGestureRecognizer *swipeGesture =[[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(swipePage:)];
//      
//        [self.current_page addGestureRecognizer:swipeGesture];
//        self.myToolbar=[[UIToolbar alloc]init];
    }
    return self;
}

- (void)viewDidLoad
{
    //initialize db
    self.dataSource =[[DataSource alloc]init];
    [self.dataSource dbConnection:@"DTech"];
    [self.dataSource tbName:@"paragraph"];
    self.myToolbar.tintColor = [UIColor brownColor];
    //get paragraph
    //forward paragraph to custom view
    cstmView = [[CustomView alloc]init];
    NSString *txt=[self.dataSource paragraph:1 para_id:1];
    
    [cstmView currentPageText:txt];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(chapterSelectdAction:) name:kChapterSelectedNotification object:nil];
    
    //splash screen
    self.splashView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 300, 350)];
    self.splashView.image = [UIImage imageNamed:@"book1.png"];
    [self.view addSubview:self.splashView];
    [self.view bringSubviewToFront:self.splashView];
    
    [self performSelector:@selector(removeSplash:) withObject:nil afterDelay:0.5];
    
    
    cstmView.frame=CGRectMake(5, 5, self.current_page.frame.size.width-10, self.current_page.frame.size.height);
    cstmView.backgroundColor =[UIColor whiteColor];
    
    UIBarButtonItem * item = [[UIBarButtonItem alloc]initWithTitle:@"Shelf" style:UIBarButtonItemStylePlain target:nil action:nil];
    self.navigationItem.leftBarButtonItem = item;
    
    
    [self.current_page addSubview: cstmView];
//    self.view = mainCanvas;
//    [self.current_page addSubview:cstmView];
    [self.myToolbar setHidden:YES];
    self.navigationController.navigationBar.hidden=YES;
    
    //---set the viewable frame of the scroll view---
    self.current_page.frame = CGRectMake(0, 0, 320, 460);
    
    //---set the content size of the scroll view---
    [self.current_page setContentSize:CGSizeMake(320, 713)];
    self.current_page.scrollEnabled=YES;
    
    [super viewDidLoad];
}

- (void) chapterSelectdAction:(NSNotification*)notif{
    NSNumber * ch_id = notif.object;
    
    [self.dataSource tbName:@"paragraph"];
    
     
    NSString *txt=[self.dataSource createPage:[ch_id intValue] childId:-1 bit:0];
    [cstmView setNeedsDisplay];
    
    [cstmView currentPageText:txt];
    NSLog(@"Selected Chapter ID is %@", ch_id);
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(IBAction)removeSplash:(id)sender
{
    [self.splashView removeFromSuperview];
    
}
-(IBAction)showContent:(id)sender
{
//    [UIView beginAnimations:@"TOC"  context:nil];
//    [UIView setAnimationDuration:0.5];
//    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
//    [UIView setAnimationTransition:UIViewAnimationTransitionNone forView:self.navigationController.navigationBar cache:YES];
//    [UIView setAnimationTransition:UIViewAnimationTransitionNone forView:self.myToolbar cache:YES];
    
    TOCViewController *cont=[[TOCViewController alloc]initWithNibName:@"TOCViewController" bundle:nil];
    cont.title=@"Table of Content";

//    [self.navigationController pushViewController:cont animated:YES];
    [self.navigationController presentViewController:cont animated:YES completion:nil];
        cont.navigationController.navigationBar.hidden=YES;
            [self.myToolbar setHidden:YES];
//     [UIView commitAnimations];

    
}
 
- (IBAction)encodeText:(id)sender {
    
}

-(IBAction)hideShowNavBar:(id)sender
{
    if (self.navigationController.navigationBar.hidden == NO) {
         [self.navigationController setNavigationBarHidden:YES animated:YES];
           self.navigationController.navigationBar.hidden=YES;
            [self.myToolbar setHidden:YES];
       
    }
    else{
          [self.navigationController setNavigationBarHidden:NO animated:NO];
        self.navigationController.navigationBar.hidden=NO;

        [self.myToolbar setHidden:NO];
        
    }
 
}
@end
