//
//  ViewController.m
//  EnjoyYourLife
//
//  Created by Faiz Rasool on 3/13/13.
//  Copyright (c) 2013 D-Tech. All rights reserved.
//

#import "ViewController.h"
#import "RootViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)ButtonTapped:(id)sender {
   
}
@end
