//
//  CustomView.m
//  TestCoreText
//
//  Created by ahadnawaz on 08/03/2013.
//  Copyright (c) 2013 ahadnawaz. All rights reserved.
//

#import "CustomView.h"

@implementation CustomView
 
-(void)currentPageText:(NSString *) txt
{
    self.text=txt;
}
 
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        //create long press gesture recognizer(gestureHandler will be triggered after gesture is detected)
        UILongPressGestureRecognizer* longPressGesture = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(gestureHandler:)];
        //adjust time interval(floating value CFTimeInterval in seconds)
        [longPressGesture setMinimumPressDuration:0.2];
        //add gesture to view you want to listen for it(note that if you want whole view to "listen" for gestures you should add gesture to self.view instead)
        [self addGestureRecognizer:longPressGesture];
        

    }
    return self;
}
-(void)gestureHandler:(UISwipeGestureRecognizer *)gesture
{
    if(UIGestureRecognizerStateBegan == gesture.state)
    {//your code here
        
//         ineRect = CGRectMake(origin.x + offset,
//                             origin.y - descent,
//                             offset,
//                             ascent + descent);
        
        NSLog(@"long pressed");
    }
}

 
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
          
    // Initialize a graphics context and set the text matrix to a known value.
    
    CGContextRef context = (CGContextRef)UIGraphicsGetCurrentContext();
    // Flip the coordinate system
    CGContextSetTextMatrix(context, CGAffineTransformIdentity);
    CGContextTranslateCTM(context, 0, self.bounds.size.height);
    CGContextScaleCTM(context, 1.0, -1.0);
    
    CGContextSetTextMatrix(context, CGAffineTransformIdentity);
    
    
    // Initialize a rectangular path.
    
    CGMutablePathRef path = CGPathCreateMutable();
    
//    CGRect bounds = CGRectMake(1.0, 1.0, 300.0, 300.0);
    
    CGPathAddRect(path, NULL, self.bounds);
    
    // Initialize an attributed string.
    
    NSMutableAttributedString *string=[[NSMutableAttributedString alloc] initWithString:(self.text)];
    
//    [string addAttribute:@"DTCustomStrikeOut"
//               value:[NSNumber numberWithBool:YES]
//               range:NSMakeRange(30, 17)];
    
    CTFontRef helvetica = CTFontCreateWithName(CFSTR("Helvetica"), 14.0, NULL);
	CTFontRef helveticaBold = CTFontCreateWithName(CFSTR("Helvetica-Bold"), 14.0, NULL);
    //applying font
	[string addAttribute:(id)kCTFontAttributeName
                   value:(__bridge id)helvetica
                   range:NSMakeRange(0, [string length])];
    
//	[string addAttribute:(id)kCTFontAttributeName
//                   value:(__bridge id)helveticaBold
//                   range:NSMakeRange(6, 50)];
//    //applying color
//    [string addAttribute:(id)kCTForegroundColorAttributeName
//                   value:(id)[UIColor redColor].CGColor
//                   range:NSMakeRange(18, 30)];
    
//	[string addAttribute:(id)kCTForegroundColorAttributeName
//                   value:(id)[UIColor greenColor].CGColor
//                   range:NSMakeRange(27, 60)];
//  
    // Create the framesetter with the attributed string.
    CTFramesetterRef framesetter = CTFramesetterCreateWithAttributedString((CFAttributedStringRef)CFBridgingRetain(string));

    CFRelease((__bridge CFTypeRef)(string));
       
    // Create the frame and draw it into the graphics context

    CTFrameRef frame = CTFramesetterCreateFrame(framesetter, CFRangeMake(0, 0), path, NULL);
    CFRange rangString= CTFrameGetVisibleStringRange(frame);
    
    CFRelease(framesetter);

    
//    ///text strike through
//    
//    // reset text position
//                CGContextSetTextPosition(context, 0, 0);
//
//                // get lines
//                CFArrayRef leftLines = CTFrameGetLines(frame);
//                CGPoint *origins = malloc(sizeof(CGPoint)*[(__bridge NSArray *)leftLines count]);
//                CTFrameGetLineOrigins(frame,
//                                      CFRangeMake(0, 0), origins);
//                NSInteger lineIndex = 0;
//
//                for (id oneLine in (__bridge NSArray *)leftLines)
//                {
//                    CFArrayRef runs = CTLineGetGlyphRuns((__bridge CTLineRef)oneLine);
//                    CGRect lineBounds = CTLineGetImageBounds((__bridge CTLineRef)oneLine, context);
//                    
//                    lineBounds.origin.x += origins[lineIndex].x;
//                    lineBounds.origin.y += origins[lineIndex].y;
//                    lineIndex++;
//                    CGFloat offset = 0;
//                    
//                    for (id oneRun in (__bridge NSArray *)runs)
//                    {
//                        CGFloat ascent = 0;
//                        CGFloat descent = 0;
//                        
//                        CGFloat width = CTRunGetTypographicBounds((__bridge CTRunRef) oneRun,
//                                                                  CFRangeMake(0, 0),
//                                                                  &ascent,
//                                                                  &descent, NULL);
//                        
//                        NSDictionary *attributes = (__bridge NSDictionary *)CTRunGetAttributes((__bridge CTRunRef) oneRun);
//                        
//                        BOOL strikeOut = [[attributes objectForKey:@"DTCustomStrikeOut"] boolValue];
//                        
//                        if (strikeOut)
//                        {
//                            CGRect bounds = CGRectMake(lineBounds.origin.x + offset,
//                                                       lineBounds.origin.y,
//                                                       width, ascent + descent);
//                            
//                            
//                            // don't draw too far to the right
//                            if (bounds.origin.x + bounds.size.width > CGRectGetMaxX(lineBounds))
//                            {
//                                bounds.size.width = CGRectGetMaxX(lineBounds) - bounds.origin.x;
//                            }
//                            
//                            // get text color or use black
//                            id color = [attributes objectForKey:(id)kCTForegroundColorAttributeName];
//                            
//                            if (color)
//                            {
//                                CGContextSetStrokeColorWithColor(context, (__bridge CGColorRef)color);
//                            }
//                            else
//                            {
//                                CGContextSetGrayStrokeColor(context, 0, 1.0);
//                            }
//                            
//                            CGFloat y = roundf(bounds.origin.y + bounds.size.height / 2.0);
//                            CGContextMoveToPoint(context, bounds.origin.x, y);
//                            CGContextAddLineToPoint(context, bounds.origin.x + bounds.size.width, y);
//                            
//                            CGContextStrokePath(context);
//                        }
//                        
//                        offset += width;
//                    }
//                }
//            // cleanup
//                free(origins);
    CTFrameDraw(frame, context);
    
    CFRelease(frame);
    CFRelease(helvetica);
	CFRelease(helveticaBold);
                ///EO Text Strikr Th
    
    
}


@end
