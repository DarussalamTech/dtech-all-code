/*
 * BookGridViewCell.h
 */

#import <Foundation/Foundation.h>
#import "AQGridView-master/Classes/AQGridViewCell.h"

@interface BookGridViewCell : AQGridViewCell
{
    UIImageView * _imageView;
}
@property (nonatomic, retain) UIImage * image;
@end
