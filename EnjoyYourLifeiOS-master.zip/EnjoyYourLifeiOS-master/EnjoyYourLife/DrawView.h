//
//  DrawView.h
//  CoreTextTest
//
//  Created by Faiz Rasool on 3/8/13.
//  Copyright (c) 2013 Darussalam Publications. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreText/CoreText.h>

@interface DrawView : UIView{
    UILongPressGestureRecognizer * gesture;
    UITapGestureRecognizer * tapGesture;
}
@property size_t columnCount;

- (CFArrayRef)createColumns;

@end
