//
//  DataViewController.m
//  CoreTextBasics
//
//  Created by Faiz Rasool on 3/8/13.
//  Copyright (c) 2013 Darussalam Publications. All rights reserved.
//

#import "DataViewController.h"


@interface DataViewController ()

@end

@implementation DataViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    self.longPressGestureRecognizer = [[UILongPressGestureRecognizer alloc]initWithTarget:self action:@selector(handleLongPress:)];
    [self.view addGestureRecognizer:self.longPressGestureRecognizer];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.dataLabel.text = [self.dataObject description];
}

#pragma mark - UIGestureRecognizer

- (void) handleLongPress:(UILongPressGestureRecognizer*)gestureRecognizer{
    CGPoint p = [gestureRecognizer locationInView:self.view];
    NSLog(@"point is x= %f, y= %f",p.x,p.y);
}

@end