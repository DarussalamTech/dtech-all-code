//
//  TOCViewController.m
//  TestCoreText
//
//  Created by ahadnawaz on 11/03/2013.
//  Copyright (c) 2013 ahadnawaz. All rights reserved.
//

#import "TOCViewController.h"
#import "coreViewController.h"

@interface TOCViewController ()

@end

@implementation TOCViewController

-(id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self=[super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
    }
    return self;
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    //initialize db
    self.dataSource =[[DataSource alloc]init];
    [self.dataSource dbConnection:@"DTech"];
    [self.dataSource tbName:@"Chapter"];
    
    self.contents=[self.dataSource TOC];// [[NSMutableArray alloc] initWithObjects:@"ch 1",@"ch 2",@"ch 3", nil];
    self.searchContents=[[NSMutableArray alloc]init];
//    [self.searchDisplayController setActive:YES animated:YES];
    
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
 
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
     return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView==self.searchDisplayController.searchResultsTableView) {
        return self.searchContents.count;
    }
    else
     return self.contents.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    // Configure the cell...
    if (tableView==self.searchDisplayController.searchResultsTableView) {
        cell.textLabel.text=[[self.searchContents objectAtIndex:indexPath.row] chapterTitle];
        
    }
    else
    cell.textLabel.text=[[self.contents objectAtIndex:indexPath.row] chapterTitle];
    
    return cell;
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }   
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

//- (NSString *) getChapterIDForChapterName:(NSString*)name{
//    return @"1";
//}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    int ch_index;
     if (tableView == self.searchDisplayController.searchResultsTableView) {
           ch_index=[[self.searchContents objectAtIndex:indexPath.row]chID];
    }
    else
       ch_index=[[self.contents objectAtIndex:indexPath.row]chID];
    NSNumber *ch_id=[NSNumber numberWithInt:ch_index];
    
    [[NSNotificationCenter defaultCenter]postNotificationName:kChapterSelectedNotification object:ch_id];
    
    [self dismissViewControllerAnimated:YES completion:nil];
}
#pragma mark - Searching

- (void)filterContentForSearchText:(NSString*)searchText scope:(NSString*)scope
{
    NSPredicate *resultPredicate = [NSPredicate
                                    predicateWithFormat:@"chapterTitle contains[cd] %@",
                                    searchText];
    
    self.searchContents = [self.contents filteredArrayUsingPredicate:resultPredicate];
}
-(BOOL)searchDisplayController:(UISearchDisplayController *)controller shouldReloadTableForSearchString:(NSString *)searchString
{
    [self filterContentForSearchText:searchString scope:[[self.searchDisplayController.searchBar scopeButtonTitles]
                                                         objectAtIndex:[self.searchDisplayController.searchBar
                                                                        selectedScopeButtonIndex]]];
    
    return YES;
}

 

@end
