//
//  BookShelfViewController.m
//  EnjoyYourLife
//
//  Created by Faiz Rasool on 3/14/13.
//  Copyright (c) 2013 D-Tech. All rights reserved.
//

#import "BookShelfViewController.h"
#import "BookGridCell.h"
#import "BookGridViewCell.h"

@interface BookShelfViewController ()

@end

@implementation BookShelfViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
//    
    self.gridView.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
	self.gridView.autoresizesSubviews = YES;
//    self.gridView.delegate = self;
////    self.gridView.dataSource = self;
//    self.gridView.leftContentInset = 6.0;
//    self.gridView.rightContentInset = 6.0;

//
    self.title = @"Shelf";
    self.gridView.layoutDirection = AQGridViewLayoutDirectionVertical;

    self.gridView.separatorStyle = AQGridViewCellSeparatorStyleEmptySpace;
    self.gridView.resizesCellWidthToFit = NO;
    self.gridView.separatorColor = nil;
    
    // load images from the bundle
   // NSArray * paths = [NSBundle pathsForResourcesOfType: @"png" inDirectory: [[NSBundle mainBundle] bundlePath]];
    NSMutableArray * allImageNames = [[NSMutableArray alloc] initWithObjects:@"Splash.png", @"Enjoy2.png",@"GodSigns.jpg", nil];
    
//    for ( NSString * path in paths )
//    {
//        if ( [[path lastPathComponent] hasPrefix: @"AQ"] )
//            continue;
//        
//        [allImageNames addObject: [path lastPathComponent]];
//    }
    
    // sort alphabetically
    self.books= [allImageNames copy];//[[allImageNames sortedArrayUsingSelector: @selector(caseInsensitiveCompare:)] copy];
    
    UIImageView * bg = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"Wood2.jpg"]];
    
    self.gridView.backgroundView = bg;
    [self.gridView reloadData];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated{
    [self.gridView reloadData];
}

- (void)viewDidUnload {
    [self setBooksGridView:nil];
    [super viewDidUnload];
}

#pragma mark - AQGridView 

- (NSUInteger)numberOfItemsInGridView:(AQGridView *)gridView{
    return self.books.count;
}

- (AQGridViewCell *)gridView:(AQGridView *)gridView cellForItemAtIndex:(NSUInteger)index{
    
    static NSString * FilledCellIdentifier = @"FilledCellIdentifier";
    BookGridCell * filledCell = (BookGridCell *)[gridView dequeueReusableCellWithIdentifier: FilledCellIdentifier];
    if ( filledCell == nil )
    {
        filledCell = [[BookGridCell alloc] initWithFrame: CGRectMake(0.0, 10.0, 100.0, 130.0)
                                                reuseIdentifier: FilledCellIdentifier];
        filledCell.selectionStyle = AQGridViewCellSelectionStyleGlow;
        filledCell.selectionGlowColor = [UIColor purpleColor];
    }
    
    filledCell.image = [UIImage imageNamed: [self.books objectAtIndex: index]];
  //  filledCell.title = @"Enjoy Your Life";//[[self.books objectAtIndex: index] stringByDeletingPathExtension];
    
    return filledCell;
}

- (CGSize)portraitGridCellSizeForGridView:(AQGridView *)gridView{
    return CGSizeMake(100, 130);
}

//- (void)gridView:(AQGridView *)gridView willDisplayCell:(AQGridViewCell *)cell forItemAtIndex:(NSUInteger)index{
//    cell.backgroundColor =  [UIColor clearColor];
//}

- (void)gridView:(AQGridView *)gridView didSelectItemAtIndex:(NSUInteger)index{

    if(index == 1){

        BookGridCell * cell = (BookGridCell*) [gridView cellForItemAtIndex:index];
        [self.view bringSubviewToFront:cell];
        [UIView animateWithDuration:1.5 delay:0 options:0 animations:^{
            cell.transform = CGAffineTransformScale(cell.transform, 3.2, 3.8);
            cell.center = self.view.center;
          
        } completion:^(BOOL finished) {
            [gridView deselectItemAtIndex:index animated:YES];              
            coreViewController * coreController = [[coreViewController alloc]initWithNibName:@"coreViewController" bundle:nil];
            [self.navigationController pushViewController:coreController animated:NO];
            cell.transform = CGAffineTransformInvert(cell.transform );
            [self.gridView reloadData];
        }];
}
}

@end
