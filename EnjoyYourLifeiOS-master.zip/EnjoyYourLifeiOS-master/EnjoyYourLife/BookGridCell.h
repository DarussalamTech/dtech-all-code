/*
 * BookGridCell.h
 *
 */

#import <UIKit/UIKit.h>
#import "AQGridView-master/Classes/AQGridViewCell.h"

@interface BookGridCell : AQGridViewCell
{
    UIImageView * _imageView;
    UILabel * _title;
}

@property (nonatomic, retain) UIImage * image;
@property (nonatomic, copy) NSString * title;

@end
