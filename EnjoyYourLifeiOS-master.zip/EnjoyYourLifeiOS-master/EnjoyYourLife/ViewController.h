//
//  ViewController.h
//  EnjoyYourLife
//
//  Created by Faiz Rasool on 3/13/13.
//  Copyright (c) 2013 D-Tech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
- (IBAction)ButtonTapped:(id)sender;

@end
