//
//  DataSource.m
//  TestCoreText
//
//  Created by ahadnawaz on 13/03/2013.
//  Copyright (c) 2013 ahadnawaz. All rights reserved.
//

#import "DataSource.h"

@implementation DataSource
EGODatabaseResult *result;

-(void) dbConnection:(NSString *)dbName
{
    //creating db connection
    NSString * path1 = [DataSource getDatabasePath];//[[NSBundle mainBundle ] pathForResource:dbName ofType:@"sqlite"];
    self.db=[EGODatabase databaseWithPath:path1];
   

}

+(void)checkAndCreateDatabase {
    NSString *docDir = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    NSString *dbFileName = [docDir stringByAppendingPathComponent:@"DTech.sqlite"];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSError *error;
    
    if (![fileManager fileExistsAtPath:dbFileName]) {
        NSString * path = [[NSBundle mainBundle]pathForResource:@"DTech" ofType:@"sqlite"];
        if(path != nil)
            [fileManager copyItemAtPath:path toPath:dbFileName error:&error];
        else {
            NSLog(@"Failed to create database");
        }
    }
}
+ (NSString*) getDatabasePath{
    NSString *docDir = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    NSString *dbFileName = [docDir stringByAppendingPathComponent:@"Dtech.sqlite"];
    NSLog(@"%@",dbFileName);
    return dbFileName;
}


-(void) tbName:(NSString *)tableName
{
    self.tbName=tableName;
}
-(NSString *) paragraph:(int)ch_id para_id:(int)p_id
{
    if (self.db==NULL) {
        return @"DB not initialized";
    }
     result=[self.db executeQuery:[NSString stringWithFormat: @"Select para_text from %@ where chapter_id=%i order by para_id",self.tbName,ch_id]];//and id>=%i
    //"Select p1.para_text from paragraph p1,paragraph p2 where p1.id=p2.para_id"
    
    NSMutableString *txt=[[NSMutableString alloc]init];
    if(result)
    {
        for (EGODatabaseRow *row in result) {
         
            NSString *decod=[[row stringForColumn:@"para_text"] stringByReplacingOccurrencesOfString:@" " withString:@""];
            NSString *decoded=[decod unicodeToString];
            [txt appendString:[NSString stringWithFormat:@"%@\n",decoded]];
            // NSLog(@"after decoding %@ \n\n",decoded);
        }
        
        return txt;
    }
    return @"Error";
    

}
-(NSMutableArray *) TOC
{  
     result=[self.db executeQuery:[NSString stringWithFormat: @"Select id,title from %@ order by id",self.tbName]];
      
    NSMutableArray *toc=[[NSMutableArray alloc]init];
    if(result)
    {
        for (EGODatabaseRow *row in result) {
              self.ch=[[Chapter alloc]init];
            NSString *decod=[row stringForColumn:@"title"];// stringByReplacingOccurrencesOfString:@" " withString:@""];
            NSString *decoded=[decod unicodeToString];
            self.ch.chID=[row intForColumn:@"id"];
            self.ch.chapterTitle=decoded;
            [toc addObject:self.ch];
            // NSLog(@"after decoding %@ \n\n",decoded);
        }
        
        return toc;
    }
    return @[@"Error",@""];
    
    
}
-(NSString *)createPage:(int)chID childId:(int)childID bit:(int)i
{
    if (i==0){
         self.page=[[NSMutableString alloc]init];
        result=[self.db executeQuery:[NSString stringWithFormat: @"Select id,para_text from %@ where chapter_id=%i and para_id =''",self.tbName,chID]];
        i++;
    }
    else{
        result=[self.db executeQuery:[NSString stringWithFormat: @"Select id,para_text from %@ where chapter_id=%i and para_id =%i",self.tbName,chID,childID]];
    }
    if (result.rows.count>0) {
         EGODatabaseRow *row=[result rowAtIndex:0];
        NSString *decod=[[row stringForColumn:@"para_text"] stringByReplacingOccurrencesOfString:@" " withString:@""];
        NSString *decoded=[decod unicodeToString];
        [self.page appendString:decoded];
        [self.page appendString:@"\n"];
         childID=[row intForColumn:@"id"];
        [self createPage:chID childId:childID bit:i];
            
    }
    
//  NSLog(@"page ==\n %@",self.page);
        return self.page;
    
}

@end