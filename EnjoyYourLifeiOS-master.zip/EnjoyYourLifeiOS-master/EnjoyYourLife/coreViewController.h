//
//  coreViewController.h
//  TestCoreText
//
//  Created by ahadnawaz on 08/03/2013.
//  Copyright (c) 2013 ahadnawaz. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomView.h"
#import <sqlite3.h>
#import "EGODatabase.h"
#import "DataSource.h"

#define kChapterSelectedNotification @"kChapterSelectedNotification"

@interface coreViewController : UIViewController <UIScrollViewDelegate>
@property (strong, nonatomic) IBOutlet UIScrollView *current_page;
@property (strong, nonatomic) IBOutlet UIToolbar *myToolbar;
@property DataSource *dataSource;
@property (strong,nonatomic)  UIImageView *splashView;

-(IBAction)hideShowNavBar:(id)sender;
@end
