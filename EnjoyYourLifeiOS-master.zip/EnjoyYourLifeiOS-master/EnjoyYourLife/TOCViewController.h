//
//  TOCViewController.h
//  TestCoreText
//
//  Created by ahadnawaz on 11/03/2013.
//  Copyright (c) 2013 ahadnawaz. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DataSource.h"

@interface TOCViewController : UIViewController <UITableViewDataSource,UITableViewDelegate,UISearchDisplayDelegate>

@property (strong,nonatomic) NSMutableArray *searchContents;
@property (strong,nonatomic) NSMutableArray *contents;
@property (strong,nonatomic) DataSource *dataSource;

@end
