//
//  BookShelfViewController.h
//  EnjoyYourLife
//
//  Created by Faiz Rasool on 3/14/13.
//  Copyright (c) 2013 D-Tech. All rights reserved.
//

#import "AQGridView-master/Classes/AQGridViewController.h"
#import "coreViewController.h"

@interface BookShelfViewController : AQGridViewController <AQGridViewDataSource, AQGridViewDelegate>

@property (unsafe_unretained, nonatomic) IBOutlet AQGridView *booksGridView;
@property (strong, nonatomic) NSMutableArray * books;
@end
