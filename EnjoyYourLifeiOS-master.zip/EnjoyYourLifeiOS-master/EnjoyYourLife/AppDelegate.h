//
//  AppDelegate.h
//  EnjoyYourLife
//
//  Created by Faiz Rasool on 3/13/13.
//  Copyright (c) 2013 D-Tech. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SplashView.h"

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@end
