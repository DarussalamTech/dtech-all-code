//
//  DrawView.m
//  CoreTextTest
//
//  Created by Faiz Rasool on 3/8/13.
//  Copyright (c) 2013 Darussalam Publications. All rights reserved.
//

#import "DrawView.h"
#import "NSString+Unicode.h"

@implementation DrawView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.columnCount = 2;
        gesture = [[UILongPressGestureRecognizer alloc]initWithTarget:self action:@selector(handleLongTap:)];
        tapGesture = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(handleTap:)];
        tapGesture.numberOfTapsRequired = 2;
        [self addGestureRecognizer:tapGesture];
        [self addGestureRecognizer:gesture];
    }
    return self;
}

- (void) handleLongTap:(UILongPressGestureRecognizer*)gestureRecognizer{
    CGPoint p = [gestureRecognizer locationInView:self];
    NSLog(@"point is x= %f, y= %f",p.x,p.y);
}

- (void) handleTap:(UITapGestureRecognizer*)gestureRecognizer{
    NSLog(@"Tap Gesture Activated.");
}

- (void) drawRect:(CGRect)rect{
    [super drawRect:rect];
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    // Flip the coordinate system
    CGContextSetTextMatrix(context, CGAffineTransformIdentity);
    CGContextTranslateCTM(context, 0, self.bounds.size.height);
    CGContextScaleCTM(context, 1.0, -1.0);
    
    CGMutablePathRef path = CGPathCreateMutable(); //1
    CGPathAddRect(path, NULL, self.bounds );
    
    
    NSString * unicodedStr = @"064A 064E 062C 0650 0628 064F 0020 0639 064E 0644 064E 0649 0020 0627 0644 0625 0646 0652 0633 064E 0627 0646 0650 0020 0623 0646 0020 064A 064E 0643 064F 0648 0646 064E 0020 0623 0645 0650 064A 0652 0646 064E 0627 064B 0020 0648 064E 0635 064E 0627 062F 0650 0642 064E 0627 064B 0020 0645 064E 0639 064E 0020 0646 064E 0641 0652 0633 0650 0647 0650 0020 0648 064E 0645 064E 0639 064E 0020 0623 064E 0647 0652 0644 0650 0647 0650 0020 0648 064E 062C 0650 064A 0652 0631 064E 0627 0646 0650 0647 0650 0020 0648 064E 0623 064E 0646 0652 0020 064A 064E 0628 0652 0630 064F 0644 064E 0020 0643 064F 0644 0651 064E 0020 062C 064F 0647 0652 062F 064D 0020 0641 0650 064A 0020 0625 0650 0639 0652 0644 0627 0621 0650 0020 0634 064E 0623 0652 0646 0650 0020 0627 0644 0648 064E 0637 064E 0646 0650 0020 0648 064E 0623 064E 0646 0652 0020 064A 064E 0639 0652 0645 064E 0644 064E 0020 0639 064E 0644 064E 0649 0020 0645 064E 0627 0020 064A 064E 062C 0652 0644 0650 0628 064F 0020 0627 0644 0633 0651 064E 0639 064E 0627 062F 064E 0629 064E 0020 0644 0650 0644 0646 0651 064E 0627 0633 0650 0020 002E 0020 0648 0644 064E 0646 0020 064A 064E 062A 0650 0645 0651 064E 0020 0644 064E 0647 064F 0020 0630 0644 0650 0643 0020 0625 0650 0644 0627 0020 0628 0650 0623 064E 0646 0652 0020 064A 064F 0642 064E 062F 0651 0650 0645 064E 0020 0627 0644 0645 064E 0646 0652 0641 064E 0639 064E 0629 064E 0020 0627 0644 0639 064E 0627 0645 0651 064E 0629 064E 0020 0639 064E 0644 064E 0649 0020 0627 0644 0645 064E 0646 0652 0641 064E 0639 064E 0629 0650 0020 0627 0644 062E 064E 0627 0635 0651 064E 0629 0650 0020 0648 064E 0647 0630 064E 0627 0020 0645 0650 062B 064E 0627 0644 064C 0020 0644 0650 0644 062A 0651 064E 0636 0652 062D 0650 064A 064E 0629 0650 0020 002E";//@"0628 0633 0645 0020 0627 0644 0644 0647 0020 0627 0644 0631 062D 0645 0646 0020 0627 0644 0631 062D 064A 0645";// @"064A 064E 062C 0650 0628 064F 0020 0639 064E 0644 064E 0649 0020 0627 0644 0625 0646 0652 0633 064E 0627 0646 0650 0020 0623 0646 0020 064A 064E 0643 064F 0648 0646 064E 0020 0623 0645 0650 064A 0652 0646 064E 0627 064B 0020 0648 064E 0635 064E 0627 062F 0650 0642 064E 0627 064B 0020 0645 064E 0639 064E 0020 0646 064E 0641 0652 0633 0650 0647 0650 0020 0648 064E 0645 064E 0639 064E 0020 0623 064E 0647 0652 0644 0650 0647 0650";
    unicodedStr = [unicodedStr stringByReplacingOccurrencesOfString:@" " withString:@""];
    NSMutableAttributedString* attString = [[NSMutableAttributedString alloc]
                                      initWithString:[unicodedStr unicodeToString]]; //2
    
    CTFontRef fontRef = CTFontCreateWithName((CFStringRef)@"Courier",
                                             26.0f, NULL);
    
    //apply the current text style //2
    NSDictionary* attrs = [NSDictionary dictionaryWithObjectsAndKeys:
                           (id)[UIColor blackColor].CGColor, kCTForegroundColorAttributeName,
                           (__bridge id)fontRef, kCTFontAttributeName,
                           (__bridge id)[UIColor brownColor].CGColor, (NSString *) kCTStrokeColorAttributeName,
                           (id)[NSNumber numberWithFloat: 0.0f], (NSString *)kCTStrokeWidthAttributeName,
                           nil];
    
    [attString addAttributes:attrs range:NSMakeRange(0, attString.length)];
    //[attString appendAttributedString:[[NSAttributedString alloc] initWithString:[unicodedStr unicodeToString] attributes:attrs] ];
    
    CFRelease(fontRef);
    
    CTFramesetterRef framesetter =
    CTFramesetterCreateWithAttributedString((__bridge CFAttributedStringRef)attString); //3
    CTFrameRef frame =
    CTFramesetterCreateFrame(framesetter,
                             CFRangeMake(0, [attString length]), path, NULL);
    
    CTFrameDraw(frame, context); //4
    
    CFRelease(frame); //5
    CFRelease(path);
    CFRelease(framesetter);
}

- (CFArrayRef)createColumns {
    
    CGRect bounds = CGRectMake(0, 0, self.bounds.size.width,
                               
                               self.bounds.size.height);
    
    int column;
    
    CGRect* columnRects = (CGRect*)calloc(self.columnCount, sizeof(*columnRects));
    
    
    
    // Start by setting the first column to cover the entire view.
    
    columnRects[0] = bounds;
    
    // Divide the columns equally across the frame's width.
    
    CGFloat columnWidth = CGRectGetWidth(bounds) / _columnCount;
    
    for (column = 0; column < _columnCount - 1; column++) {
        
        CGRectDivide(columnRects[column], &columnRects[column],
                     
                     &columnRects[column + 1], columnWidth, CGRectMinXEdge);
        
    }
    
    
    
    // Inset all columns by a few pixels of margin.
    
    for (column = 0; column < _columnCount; column++) {
        
        columnRects[column] = CGRectInset(columnRects[column], 10.0, 10.0);
        
    }
    
    
    
    // Create an array of layout paths, one for each column.
    
    CFMutableArrayRef array = CFArrayCreateMutable(kCFAllocatorDefault,
                                                   
                                                   _columnCount, &kCFTypeArrayCallBacks);
    
    for (column = 0; column < _columnCount; column++) {
        
        CGMutablePathRef path = CGPathCreateMutable();
        
        CGPathAddRect(path, NULL, columnRects[column]);
        
        CFArrayInsertValueAtIndex(array, column, path);
        
        CFRelease(path);
        
    }
    
    free(columnRects);
    
    return array;
    
}


/*
- (void)drawRect:(NSRect)rect {
    
    // Draw a white background.
    
    [[NSColor whiteColor] set];
    
    [NSBezierPath fillRect:[self bounds]];
    
    
    
    // Initialize the text matrix to a known value.
    
    CGContextRef context = (CGContextRef)[[NSGraphicsContext currentContext]
                                          
                                          graphicsPort];
    
    CGContextSetTextMatrix(context, CGAffineTransformIdentity);
    
    
    
    CTFramesetterRef framesetter =
    
    CTFramesetterCreateWithAttributedString(
                                            
                                            (CFAttributedStringRef)[self attributedString]);
    
    CFArrayRef columnPaths = [self createColumns];
    
    
    
    CFIndex pathCount = CFArrayGetCount(columnPaths);
    
    CFIndex startIndex = 0;
    
    int column;
    
    for (column = 0; column < pathCount; column++) {
        
        CGPathRef path = (CGPathRef)CFArrayGetValueAtIndex(columnPaths, column);
        
        
        
        // Create a frame for this column and draw it.
        
        CTFrameRef frame = CTFramesetterCreateFrame(framesetter,
                                                    
                                                    CFRangeMake(startIndex, 0), path, NULL);
        
        CTFrameDraw(frame, context);
        
        
        
        // Start the next frame at the first character not visible in this frame.
        
        CFRange frameRange = CTFrameGetVisibleStringRange(frame);
        
        startIndex += frameRange.length;
        
        
        
        CFRelease(frame);
        
    }
    
    CFRelease(columnPaths);
    
}
*/
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
