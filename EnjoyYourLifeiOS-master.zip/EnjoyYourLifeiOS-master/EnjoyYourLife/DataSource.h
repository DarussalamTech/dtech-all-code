//
//  DataSource.h
//  TestCoreText
//
//  Created by ahadnawaz on 13/03/2013.
//  Copyright (c) 2013 ahadnawaz. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sqlite3.h>
#import "EGODatabase.h"
#import "NSString+Unicode.h"
#import "Chapter.h"

@interface DataSource : NSObject
@property (strong,nonatomic) EGODatabase *db;
@property (strong,nonatomic) Chapter *ch;
@property (strong,nonatomic) NSString *tbName;
@property (strong,nonatomic) NSMutableString *page;

-(void) dbConnection:(NSString *)dbName;
-(void) tbName:(NSString *)tableName;
-(NSMutableArray *) TOC;
-(NSString *) paragraph:(int) ch_id para_id:(int)p_id;
-(NSString *)createPage:(int)chID childId:(int)childID bit:(int)i;
+(void)checkAndCreateDatabase;
+ (NSString*) getDatabasePath;

@end
