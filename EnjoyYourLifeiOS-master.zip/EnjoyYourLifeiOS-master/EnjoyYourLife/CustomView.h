//
//  CustomView.h
//  TestCoreText
//
//  Created by ahadnawaz on 08/03/2013.
//  Copyright (c) 2013 ahadnawaz. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreText/CoreText.h>
#import <QuartzCore/QuartzCore.h>
#import "EGODatabase.h"
#import "NSString+Unicode.h"

@interface CustomView : UIView
@property (strong,nonatomic) NSString *text;
 
-(void)currentPageText:(NSString *) txt;

@end
