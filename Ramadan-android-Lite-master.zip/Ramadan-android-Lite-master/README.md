Ramadan-android-Lite
====================
