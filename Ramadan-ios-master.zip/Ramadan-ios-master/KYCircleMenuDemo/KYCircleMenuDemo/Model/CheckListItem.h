//
//  CheckListItem.h
//  Ramadan
//
//  Created by Faiz Rasool on 5/28/13.
//  Copyright (c) 2013 Kjuly. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CheckListItem : NSObject

@property (nonatomic) int cheklistID;
@property (nonatomic) int categoryID;
@property (nonatomic, strong) NSString * checklistText;
@property (nonatomic, strong) NSString * checklistDate;
@property (nonatomic) int status;

@end
