//
//  CustomText.m
//  
//
//  Created by ahadnawaz on 26/04/2013.
//  Copyright (c) 2013 . All rights reserved.
//

#import "CustomText.h"

@implementation CustomText

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.dvController =[[DetailViewController alloc]init];
    }
    return self;
}
  
- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text;
{
    if ( [text isEqualToString:@"\n"] ) {
        
    }
    else
    {
        NSString *yourstring = [[NSString alloc]init];
        yourstring = textView.text;
        CGSize s = [yourstring sizeWithFont:[UIFont systemFontOfSize:15] //define your textview font size
                          constrainedToSize:CGSizeMake(self.bounds.size.width - 40, MAXFLOAT)  // - 40 For cell padding
                              lineBreakMode:UILineBreakModeWordWrap];
//        CGRect frame = CGRectMake(0.0f, s.height+10, 320.0f, 20);//use YourImageView. height and width
        
//        YourImageView.frame=frame;
        CGRect frame =  [self.dvController getImageFrame];
        [self.dvController imageFrame:frame];

    }
    return YES;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
