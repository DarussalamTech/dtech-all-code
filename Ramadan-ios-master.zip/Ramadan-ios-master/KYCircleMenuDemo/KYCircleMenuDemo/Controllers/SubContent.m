//
//  DetailViewController.m
//
//
//  Created by ahadnawaz on 24/04/2013.
//  Copyright (c) 2013 . All rights reserved.
//

#import "SubContent.h"

@interface SubContent ()

@end

@implementation SubContent


-(void)viewDidAppear:(BOOL)animated
{
    //   [self.navigationController.navigationBar  setBarStyle:UIBarStyleBlackTranslucent];
}
- (void)viewDidLoad
{
    //    [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@"top-bg-list.png"] forBarMetrics:UIBarMetricsDefault];
    
    self.view.backgroundColor = [UIColor colorWithRed:49.0/255.0 green:49.0/255.0 blue:50.0/255.0 alpha:1];
    //    self.headerView.backgroundColor = [UIColor grayColor];
    //    [self.headerView addSubview:[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"top-bg-list.png"]]];
    //    [self.headerView bringSubviewToFront:self.headerTitle];
    //    [self.headerView bringSubviewToFront:self.headerImage];
    //
    self.headerImage.image =[UIImage imageNamed:[NSString stringWithFormat:@"icn-%@.png",self.title]];
    self.headerTitle.text = self.title;//[NSString stringWithFormat:@"Fast"];
    self.headerTitle.textColor = [UIColor whiteColor];
    //    CGRect bounds= [[UIScreen mainScreen]bounds];
    //    UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, bounds.size.width, bounds.size.height)];
    //    imgView.image = [UIImage imageNamed:@"background@2x.png"];
    //
    //    [self.view addSubview:imgView];
    //    [self.view bringSubviewToFront:self.myTableView];
    self.myTableView.backgroundColor = [UIColor clearColor];
    self.myTableView.rowHeight = 40;
    self.myTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    [super viewDidLoad];
    
    //    self.contents = [[Content alloc]init];
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    // Return the number of rows in the section.
    return [self.topics count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = nil ;
    static NSString *cellIdentifier = @"Cell";
    //    if (!nibsRegistered) {
    //        UINib *nib = [UINib nibWithNibName:@"CustomCell" bundle:nil];
    //        [tableView registerNib:nib forCellReuseIdentifier:cellIdentifier];
    ////        cell.Content.font = [UIFont systemFontOfSize:15];
    //        cell.Content.numberOfLines = 0;
    //        nibsRegistered = YES;
    //
    //    }
    
    
    cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
        cell.textLabel.font =[UIFont fontWithName:@"Helvetica-Bold" size:16.0];
        cell.textLabel.textColor = [UIColor colorWithRed:191.0/255.0 green:191.0/255.0 blue:196.0/255.0 alpha:1];
        cell.backgroundView =[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"list-cell.png"]];
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
    }
    
    // Configure the cell...
    cell.textLabel.text =  [self.topics objectAtIndex:indexPath.row];
    cell.imageView.image = [UIImage imageNamed:@"dot.png"];
    return cell;
}
//-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
//{
//    [cell setSeparatorStyle:UITableViewCellSeparatorStyleNone];
////    [cell addSubview:[UIImage imageNamed:@"yourImg.png"]];
//}

/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
 {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 */

/*
 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
 {
 if (editingStyle == UITableViewCellEditingStyleDelete) {
 // Delete the row from the data source
 [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
 }
 else if (editingStyle == UITableViewCellEditingStyleInsert) {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
 }
 }
 */

/*
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
 {
 }
 */

/*
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
 {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Selecting Categories
    if([self.headerTitle.text caseInsensitiveCompare:@"Plan Your Ramadan"] == NSOrderedSame){
        CheckListViewController * checklist = [[CheckListViewController alloc]initWithNibName:@"CheckListViewController" bundle:nil];
        DataSource * dSource = [DataSource sharedInstance];
        [checklist setDataSource:[dSource getChecklistForCategory:indexPath.row+1]];
        [checklist setSelectedCategory:indexPath.row + 1];
        self.navController =[[UINavigationController alloc] initWithRootViewController:checklist];
        
        [self.sidePanelController setCenterPanel:self.navController];
    }
    else{
        NSString *content = [[self.topics objectAtIndex:indexPath.row] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
        
        self.detailViewController = [[DetailViewController alloc] initWithNibName:@"DetailViewController" bundle:nil];
        self.detailViewController.title = self.title;
        
        self.detailViewController.fileName = [NSString stringWithFormat:@"%@-%@",self.title,content];
        self.detailViewController.heading = content;
        self.navController =[[UINavigationController alloc] initWithRootViewController:self.detailViewController];
        
        [self.sidePanelController setCenterPanel:self.navController];
    }
}

-(IBAction)showMainTOC:(id)sender
{
    //  TOCViewController  *dvCont = [[TOCViewController alloc]initWithNibName:@"TOCViewController" bundle:nil];
    AnimationViewController   *dvCont = [[AnimationViewController alloc]initWithNibName:@"AnimationViewController" bundle:nil];
    //    dvCont.outlineDict = [self.dbSource getTopicsOutline:0 index:1];
    
    [self.navigationController pushViewController:dvCont animated:YES ];
    NSLog(@"inside main toc");
}

- (void)dealloc {
    [_myTableView release];
    
    [_headerView release];
    [super dealloc];
}
- (void)viewDidUnload {
    [self setMyTableView:nil];
    [self setHeader:nil];
    [self setHeaderImage:nil];
    [self setHeaderTitel:nil];
    [self setHeaderView:nil];
    [super viewDidUnload];
}
@end
