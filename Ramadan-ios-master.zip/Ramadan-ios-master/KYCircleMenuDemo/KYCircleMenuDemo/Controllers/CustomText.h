//
//  CustomText.h
//  
//
//  Created by ahadnawaz on 26/04/2013.
//  Copyright (c) 2013 . All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DetailViewController.h"

@interface CustomText : UITextView
@property DetailViewController *dvController;
@end
