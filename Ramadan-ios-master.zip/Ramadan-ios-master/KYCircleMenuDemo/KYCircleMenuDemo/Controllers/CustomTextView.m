//
//  CustomTextView.m
//  EnjoyYourLife
//
//  Created by Faiz Rasool on 4/26/13.
//  Copyright (c) 2013 Darussalam Publications. All rights reserved.
//

#import "CustomTextView.h"

@implementation CustomTextView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        
        [self setup];
        /*
        // Handle long press gesture to show custom menu options
        self.gesture = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPress:)];
        [self addGestureRecognizer:self.gesture];
        
        UIMenuItem * increaseItem = [[UIMenuItem alloc]initWithTitle:@"Increase Font" action:@selector(increaseFontSize:)];
        UIMenuItem * decreaseItem = [[UIMenuItem alloc]initWithTitle:@"Decrease Font" action:@selector(decreaseFontSize:)];
        [[UIMenuController sharedMenuController]setMenuItems:[NSArray arrayWithObjects:increaseItem,decreaseItem, nil]];
         */
    }
    return self;
}

- (void)awakeFromNib{
    [self setup];
    /*
    self.gesture = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPress:)];
    [self addGestureRecognizer:self.gesture];
    
    UIMenuItem * increaseItem = [[UIMenuItem alloc]initWithTitle:@"Increase Font" action:@selector(increaseFontSize:)];
    UIMenuItem * decreaseItem = [[UIMenuItem alloc]initWithTitle:@"Decrease Font" action:@selector(decreaseFontSize:)];
    [[UIMenuController sharedMenuController]setMenuItems:[NSArray arrayWithObjects:increaseItem,decreaseItem, nil]];
     */
}

/*
- (void) longPress:(UILongPressGestureRecognizer *) gestureRecognizer {
    if ([gestureRecognizer state] == UIGestureRecognizerStateBegan) {
        UIMenuController *theMenu = [UIMenuController sharedMenuController];
        CGRect selectionRect = CGRectMake (0, 0, self.frame.size.width, self.frame.size.height);
        [theMenu setTargetRect:selectionRect inView:self];
        theMenu.arrowDirection = UIMenuControllerArrowDefault;
        
        [theMenu setMenuVisible:YES animated:YES];
    }
}
*/
/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect
 {
 // Drawing code
 }
 */

- (void)setup{
    self.gesture = [[UIPinchGestureRecognizer alloc]initWithTarget:self action:@selector(handlePinch:)];
    [self addGestureRecognizer:self.gesture];
}


- (void) handlePinch:(UIPinchGestureRecognizer*)sender{
    if(sender.state == UIGestureRecognizerStateChanged){
        
        CGFloat scale = sender.scale;
        UIFont * font = self.font;
        
        if(scale < 1.0f){
            if(self.font.pointSize <= kMinFontSize )
                return;

            self.font = [UIFont fontWithName:font.familyName size:font.pointSize - kFontIncreaseFactor];
        }
        else{
            if(self.font.pointSize >= kMaxFontSize)
                return;

            self.font = [UIFont fontWithName:font.familyName size:font.pointSize + kFontIncreaseFactor];
        }
    }
}

#pragma mark - Menu Action Methods

- (void) increaseFontSize:(id)sender{
    if(self.font.pointSize >= kMaxFontSize)
        return;
    else{
        
        NSMutableAttributedString * attString = [[NSMutableAttributedString alloc]initWithString:self.attributedText.string];
        [attString addAttribute:(id)kCTFontAttributeName value:[UIFont systemFontOfSize:self.font.pointSize + 2] range:NSMakeRange(0, self.attributedText.string.length)];
        [self setAttributedText:attString];
    }
}

- (void) decreaseFontSize:(id)sender{
    if(self.font.pointSize <= kMinFontSize)
        return;
    else{
        NSMutableAttributedString * attString = [[NSMutableAttributedString alloc]initWithString:self.attributedText.string];
        [attString addAttribute:(id)kCTFontAttributeName value:[UIFont systemFontOfSize:self.font.pointSize - 2] range:NSMakeRange(0, self.attributedText.string.length)];
        [self setAttributedText:attString];
    }
}

#pragma mark -
- (BOOL)canPerformAction:(SEL)action withSender:(id)sender
{
    if (action == @selector(cut:) || action == @selector(copy:) || action == @selector(paste:))
        return NO;
    if (action == @selector(selectAll:))
        return NO;
    if (action == @selector(increaseFontSize:))
        return YES;
    if (action == @selector(decreaseFontSize:))
        return YES;
    return [super canPerformAction:action withSender:sender];
}


@end
