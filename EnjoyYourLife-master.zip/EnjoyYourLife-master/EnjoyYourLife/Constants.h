//
//  Constants.h
//  EnjoyYourLife
//
//  Created by RAC on 2/20/13.
//  Copyright (c) 2013 Darussalam Publications. All rights reserved.
//

#import <Foundation/Foundation.h>

#define setFONTSize(x) [UIFont systemFontOfSize:x]
#define FONT_SIZE(x) x
static float defaultFontSize = 15;