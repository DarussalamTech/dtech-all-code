//
//  ViewController.h
//  EnjoyYourLife
//
//  Created by RAC on 2/19/13.
//  Copyright (c) 2013 Darussalam Publications. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BAMSettings.h"
#import "Constants.h"
#import <sqlite3.h>

@interface ViewController : UIViewController <UITableViewDataSource, UITableViewDelegate, UISearchDisplayDelegate, BAMSettingsDelegate>

@property (nonatomic, strong) NSMutableArray * dataSource;
@property (nonatomic, strong) NSArray * searchResults;

@property (weak, nonatomic) IBOutlet UITableView *myTableView;


- (IBAction)goToFirstChapter:(id)sender;
- (IBAction)goToLastChapter:(id)sender;

@end
