//
//  ViewController.m
//  EnjoyYourLife
//
//  Created by RAC on 2/19/13.
//  Copyright (c) 2013 Darussalam Publications. All rights reserved.
//

#import "ViewController.h"
#import "BAMSettings.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    [self.navigationController.navigationBar setTintColor:[UIColor brownColor]];
    //[self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@"logo.png"] forBarMetrics:UIBarMetricsDefault];
    self.title = @"Enjoy Your Life";
    
    self.dataSource = [[NSMutableArray alloc]init];
    // Add dummy data
    for(int i=1; i<=91; i++)
        [self.dataSource addObject:[NSString stringWithFormat:@"Chapter %d",i]];
   // [self showAlert];
}
- (void)viewWillAppear:(BOOL)animated{
    [self showAlert];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)showAlert{
    NSUInteger size = [[NSUserDefaults standardUserDefaults]floatForKey:@"FontSize"];
    defaultFontSize = size;
//    UIAlertView * alrt = [[UIAlertView alloc]initWithTitle:[NSString stringWithFormat:@"Font Size is %f",defaultFontSize] message:nil delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
//    [alrt show];
    [self.myTableView reloadSections:[NSIndexSet indexSetWithIndex:0] withRowAnimation:UITableViewRowAnimationAutomatic];
}

#pragma mark - UITableView

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (tableView == self.searchDisplayController.searchResultsTableView) {
        return [self.searchResults count];
        
    } else {
        return [self.dataSource count];
        
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    static NSString * cellIdentifier = @"Cell";
    
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if(cell == nil){
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        cell.textLabel.font = [UIFont systemFontOfSize:defaultFontSize];
    }
    
    // Configure Cell
    if (tableView == self.searchDisplayController.searchResultsTableView) {
        cell.textLabel.text = [self.searchResults objectAtIndex:indexPath.row];
    } else {
        cell.textLabel.text = [self.dataSource objectAtIndex:indexPath.row];
    }
    
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSIndexPath *index = nil;
    
//    BAMSettings *settings = [[BAMSettings alloc] initWithTitle:@"Settings" propertyListNamed:@"Root"];
//    settings.delegate = self;
//    [self.navigationController pushViewController:settings animated:YES];
//    
    if ([self.searchDisplayController isActive]) {
        index = [self.searchDisplayController.searchResultsTableView indexPathForSelectedRow];
        
        
    } else {
        index = [tableView indexPathForSelectedRow];
    }
}

#pragma mark - Settings
- (void)settingsDidChangeValueForKey:(NSString *)key{
    [self showAlert];
}

#pragma mark - Searching

- (void)filterContentForSearchText:(NSString*)searchText scope:(NSString*)scope
{
    NSPredicate *resultPredicate = [NSPredicate
                                    predicateWithFormat:@"SELF contains[cd] %@",
                                    searchText];

    self.searchResults = [self.dataSource filteredArrayUsingPredicate:resultPredicate];
}

-(BOOL)searchDisplayController:(UISearchDisplayController *)controller
shouldReloadTableForSearchString:(NSString *)searchString
{
    [self filterContentForSearchText:searchString
                               scope:[[self.searchDisplayController.searchBar scopeButtonTitles]
                                      objectAtIndex:[self.searchDisplayController.searchBar
                                                     selectedScopeButtonIndex]]];

    return YES;
}


#pragma mark - Chapter Navigation

- (IBAction)goToFirstChapter:(id)sender {
    [self.myTableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] atScrollPosition:UITableViewScrollPositionTop animated:YES];
}

- (IBAction)goToLastChapter:(id)sender {
        [self.myTableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:self.dataSource.count - 1 inSection:0] atScrollPosition:UITableViewScrollPositionBottom animated:YES];
}
@end
