//
//  DataSource.m
//  Ramadan
//
//  Created by ahadnawaz on 29/04/2013.
//  Copyright (c) 2013 Kjuly. All rights reserved.
//

#import "DataSource.h"

@implementation DataSource

EGODatabaseResult *result;

static DataSource * dataSource;
static EGODatabase *db;

+ (DataSource*) sharedInstance{
    if(dataSource == nil){
        dataSource = [[DataSource alloc]init];
        db = [EGODatabase databaseWithPath:[DataSource getDatabasePath]];
    }
    return dataSource;
}

+(NSArray *) getContent:(NSString *)fileName
{
    NSString *filePath = [[NSBundle mainBundle] pathForResource:fileName ofType:@"txt"];
    //NSLog(@"filePath: %@", filePath);
    
    NSString *fileString = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil];
    //      NSLog(@"fileString: %@", fileString);
    
    NSArray *lines = [fileString componentsSeparatedByString:@"\n"];
    return lines;
}
+(NSString *) getDetailFile:(NSString *)fileName
{
    NSString *filePath = [[NSBundle mainBundle] pathForResource:fileName ofType:@"txt"];
    //    NSLog(@"filePath: %@", filePath);
    
    NSString *fileString = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil];
    //    NSLog(@"fileString: %@", fileString);
    
    return fileString;
}


// Database operations

+(void)checkAndCreateDatabase {
    NSString *docDir = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    NSString *dbFileName = [docDir stringByAppendingPathComponent:fullDataBaseName];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSError *error;
    
    NSDictionary * attributes = [fileManager attributesOfItemAtPath:dbFileName error:nil];
    NSInteger fileSize = (NSInteger)[attributes objectForKey:NSFileSize];
    
    if (![fileManager fileExistsAtPath:dbFileName] || fileSize == 0) {
        NSString * path = [[NSBundle mainBundle]pathForResource:dataBaseName ofType:@"sqlite"];
        if(path != nil)
            [fileManager copyItemAtPath:path toPath:dbFileName error:&error];
        else {
            //NSLog(@"Failed to create database");
        }
    }
}

+ (NSString*) getDatabasePath{
    NSString *docDir = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    NSString *dbFileName = [docDir stringByAppendingPathComponent:fullDataBaseName];
    // NSLog(@"%@",dbFileName);
    return dbFileName;
}

- (NSMutableArray*) getChecklistForCategory:(int)categoryID{
    
    EGODatabase * database = [EGODatabase databaseWithPath:[DataSource getDatabasePath]];
    
    NSMutableArray * checkList = [[NSMutableArray alloc]init];
    EGODatabaseResult* result=[database executeQuery:[NSString stringWithFormat: @"Select * From CheckList where category_id = %d",categoryID]];//(Select name From Category where id = %d)",categoryID]];
    
    for(EGODatabaseRow * row in result) {
        //        EGODatabaseRow *row=[result rowAtIndex:0];
        
        CheckListItem * ch = [[CheckListItem alloc]init];
        ch.checklistText = [row stringForColumn:@"checklist_text"];
        ch.cheklistID = [row intForColumn:@"id"];
        ch.categoryID = [row intForColumn:@"category_id"];
        ch.checklistDate = [row stringForColumn:@"checklist_date"];
        ch.status = [row intForColumn:@"status"];
        
        [checkList addObject:ch];
        
        [ch release];
    }
    return checkList;
}

- (NSMutableArray*) getChecklistForDate:(NSString*)date{
    EGODatabase * database = [EGODatabase databaseWithPath:[DataSource getDatabasePath]];
    
    NSMutableArray * checkList = [[NSMutableArray alloc]init];
    EGODatabaseResult* result=[database executeQuery:[NSString stringWithFormat: @"Select * From Activity where date_marked = '%@'",date]];//(Select name From Category where id = %d)",categoryID]];
    
    for(EGODatabaseRow * row in result) {
        //        EGODatabaseRow *row=[result rowAtIndex:0];
        
        CheckListItem * ch = [[CheckListItem alloc]init];
        ch.cheklistID = [row intForColumn:@"checklist_id"];
        ch.categoryID = [row intForColumn:@"category_id"];
        ch.checklistDate = [row stringForColumn:@"date_marked"];
        
        [checkList addObject:ch];
        
        [ch release];
    }
    return checkList;
}

- (void) markTaskAsDone:(int)checklistID categoryID:(int)catID date:(NSString*)dateMarked{
    EGODatabase * database = [EGODatabase databaseWithPath:[DataSource getDatabasePath]];
    NSString * sql = [NSString stringWithFormat:@"Insert into Activity (checklist_id, category_id, date_marked) Values(%d, %d, '%@')",checklistID, catID, dateMarked];
    EGODatabaseResult * result = [database executeQuery:sql];
}

- (void) unMarkTask:(int)checklistID categoryID:(int)catID date:(NSString*)dateMarked{
    EGODatabase * database = [EGODatabase databaseWithPath:[DataSource getDatabasePath]];
    NSString * sql = [NSString stringWithFormat:@"Delete from Activity where checklist_id = %d AND category_id = %d AND date_marked = '%@'",checklistID, catID, dateMarked];
    EGODatabaseResult * result = [database executeQuery:sql];
}

- (NSMutableArray*) getAllCategories{
    EGODatabase * database = [EGODatabase databaseWithPath:[DataSource getDatabasePath]];
    NSMutableArray * categories = [[NSMutableArray alloc]init];
    EGODatabaseResult* result=[database executeQuery:@"Select name From Category"];
    
    for(EGODatabaseRow * row in result) {
        
        NSString * name = [row stringForColumn:@"name"];
        [categories addObject:name];   
    }
    return categories;
}

@end
