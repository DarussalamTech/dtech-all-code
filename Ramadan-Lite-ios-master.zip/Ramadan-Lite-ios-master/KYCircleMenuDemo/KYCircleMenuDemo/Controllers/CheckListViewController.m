//
//  CheckListViewController.m
//  Ramadan
//
//  Created by Faiz Rasool on 5/23/13.
//  Copyright (c) 2013 Kjuly. All rights reserved.
//

#import "CheckListViewController.h"

@interface CheckListViewController ()

@end

@implementation CheckListViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    //adding button to right of navigation bar
    UIButton * btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn setBackgroundImage:[UIImage imageNamed:@"home.png"] forState:UIControlStateNormal];
    btn.frame = CGRectMake(0, 0, 27, 44);
    [btn addTarget:self action:@selector(gotoHomeMenue:)  forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem * homeBtn = [[UIBarButtonItem alloc] initWithCustomView:btn];
    self.navigationItem.rightBarButtonItem = homeBtn;
    
    self.navigationItem.titleView = self.navigationView;
    
    self.today = [NSDate date];
    
    NSDateFormatter * df = [[NSDateFormatter alloc]init];
    [df setDateStyle:NSDateFormatterMediumStyle];
    self.headerTitleLabel.text = [df stringFromDate:self.today];
    self.selectedDate = [NSDate date];
    [self getChecklistItemsForDate:self.headerTitleLabel.text];
}

- (void) gotoHomeMenue:(id)sender{
    [self dismissModalViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - UITableView

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.dataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString *cellIdentifier=@"cellIdentifier";
    cell  = (CustomCellViewController*)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if(cell == nil){
        UINib *nib = [UINib nibWithNibName:@"CustomCellViewController" bundle:nil];
        NSArray* topLevelObjects = [nib instantiateWithOwner:nil options:0];
        cell = [topLevelObjects objectAtIndex:0];
        //        cell.taskLabel.font = [UIFont systemFontOfSize:15];
        //        cell.taskLabel.numberOfLines = 0;
    }
    
    CheckListItem * item = nil;
    if(self.dataSource.count > 0)
        item = [self.dataSource objectAtIndex:indexPath.row];
    if(item != nil){
        cell.tickButton.tag = item.cheklistID;
        cell.taskLabel.text = item.checklistText;
        cell.dateLabel.text = self.headerTitleLabel.text;
        [cell.tickButton addTarget:self action:@selector(tickButtonTapped:) forControlEvents:UIControlEventTouchUpInside];
        if(item.status == 1)
            cell.tickButton.selected = YES;
        else
            cell.tickButton.selected = NO;
        
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

}

-(void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath
{
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 80;
}

- (void) tickButtonTapped:(UIButton*)sender{
    // save the checklist item that is done for today
    NSDateFormatter * df = [[NSDateFormatter alloc]init];
    [df setDateStyle:NSDateFormatterMediumStyle];
    NSString * dateString = [df stringFromDate:self.selectedDate];
    
    if(sender.selected)
        [[DataSource sharedInstance]markTaskAsDone:sender.tag categoryID:self.selectedCategory date:dateString];
    else
        [[DataSource sharedInstance]unMarkTask:sender.tag categoryID:self.selectedCategory date:dateString];
    
    [self getChecklistItemsForDate:self.headerTitleLabel.text];
}

- (void) getChecklistItemsForDate:(NSString*)date{
        
    self.dataSource = [[DataSource sharedInstance] getChecklistForCategory:self.selectedCategory];
    NSMutableArray * checkedItems = [[DataSource sharedInstance]getChecklistForDate:date];
    
    for(int i=0; i<self.dataSource.count; i++){
        for(int j=0; j<checkedItems.count; j++){
            CheckListItem * jItem = [checkedItems objectAtIndex:j];
            CheckListItem * iItem = [self.dataSource objectAtIndex:i];
            
            if(iItem.cheklistID == jItem.cheklistID && [jItem.checklistDate isEqualToString:self.headerTitleLabel.text]){
                iItem.status = 1;
                [self.dataSource replaceObjectAtIndex:i withObject:iItem];
            }
        }
    }
    [self.tasksTableView reloadData];
}

#pragma mark -

- (void)dealloc {
    [_tasksTableView release];
    [_dayLabel release];
    [_navigationView release];
    [_headerTitleLabel release];
    [super dealloc];
}

- (void)viewDidUnload {
    [self setTasksTableView:nil];
    [self setDayLabel:nil];
    [self setNavigationView:nil];
    [self setHeaderTitleLabel:nil];
    [super viewDidUnload];
}


int count = 1;
- (IBAction)nextDayButtonTapped:(id)sender {
    // next day by adding the number of seconds in one day
    self.selectedDate = [self.selectedDate dateByAddingTimeInterval:86400];
    
    NSDateFormatter * df = [[NSDateFormatter alloc]init];
    [df setDateStyle:NSDateFormatterMediumStyle];
    self.headerTitleLabel.text = [df stringFromDate:self.selectedDate];

    [self getChecklistItemsForDate:self.headerTitleLabel.text];
}

- (IBAction)previousDayButtonTapped:(id)sender {
    // previous day by subtracting the number of seconds in one day
    self.selectedDate = [self.selectedDate dateByAddingTimeInterval:-86400];
    
    NSDateFormatter * df = [[NSDateFormatter alloc]init];
    [df setDateStyle:NSDateFormatterMediumStyle];
    self.headerTitleLabel.text = [df stringFromDate:self.selectedDate];
    
    [self getChecklistItemsForDate:self.headerTitleLabel.text];    
}
@end
