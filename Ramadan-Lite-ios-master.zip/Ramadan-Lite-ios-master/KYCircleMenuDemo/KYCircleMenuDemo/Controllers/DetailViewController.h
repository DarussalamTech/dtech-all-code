//
//  DetailViewController.h
//  
//
//  Created by ahadnawaz on 26/04/2013.
//  Copyright (c) 2013 . All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DataSource.h"
#import "NSString+Unicode.h"
#import "CustomTextView.h"

@class EGOTextView;
@interface DetailViewController : UIViewController
@property (retain, nonatomic) IBOutlet CustomTextView *textView;
@property (strong, nonatomic) NSString *fileName;
@property (strong, nonatomic) NSString *heading;
@property (retain, nonatomic) IBOutlet UILabel *contentHeading;
@property (retain, nonatomic) EGOTextView *contentTextView;
@property (retain, nonatomic) IBOutlet UIView *textContainerView;

-(void) imageFrame:(CGRect )frame;
-(CGRect)getImageFrame;

- (IBAction)increaseFontButtonTapped:(id)sender;
- (IBAction)decreaseFontButtonTapped:(id)sender;


@end
