//
//  DetailViewController.h
//  
//
//  Created by ahadnawaz on 24/04/2013.
//  Copyright (c) 2013. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "DataSource.h"
#import "DetailViewController.h"
#import "AnimationViewController.h"
#import "CheckListViewController.h"
//#import "CustomCell.h"

@interface SubContent: UIViewController <UITableViewDataSource,UITableViewDelegate>
@property (nonatomic,strong) NSArray *topics;
@property (retain, nonatomic) IBOutlet UITableView *myTableView;
@property (retain, nonatomic) IBOutlet UIImageView *headerImage;
@property (retain, nonatomic) IBOutlet UIView *headerView;
@property (retain, nonatomic) IBOutlet UILabel *headerTitle;

 
@property (nonatomic,strong) DetailViewController *detailViewController;
@property (nonatomic,strong) UINavigationController * navController;

@end
