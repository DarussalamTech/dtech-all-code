//
//  DetailViewController.m
//  
//
//  Created by ahadnawaz on 26/04/2013.
//  Copyright (c) 2013. All rights reserved.
//

#import "DetailViewController.h"
#import "NIHTMLParser.h"
#import "EGOTextView.h"
#import "NIHTMLElement+NSAttributedString.h"
#import "NIAttributedLabel.h"

@interface DetailViewController ()

@end

@implementation DetailViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{

    [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@"top-strop-1.png"] forBarMetrics:UIBarMetricsDefault];
    
    CGRect frame = [UIScreen mainScreen].bounds;
    frame.origin.x = 10;
    frame.origin.y = 50;
    frame.size.width = 300;
    if(frame.size.height > 480)
        frame.size.height = frame.size.height - 125;
    else
        frame.size.height = frame.size.height - 40;
    self.contentTextView = [[EGOTextView alloc]initWithFrame:frame];
    self.contentTextView.editable = NO;
    self.contentTextView.backgroundColor = [UIColor blackColor];
    self.contentTextView.textInputView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:self.contentTextView];
    
    //navigation title setting
    UILabel * label = [[UILabel alloc] initWithFrame:CGRectMake(0,0,150,150)] ;
    label.textColor = [UIColor blackColor];
    label.backgroundColor = [UIColor clearColor];
    label.text = self.navigationItem.title;
    label.font = [UIFont boldSystemFontOfSize:20.0];
    self.navigationItem.titleView = label;
    [label sizeToFit];
     
    //adding button to right of navigation bar
    UIButton * btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn setBackgroundImage:[UIImage imageNamed:@"home.png"] forState:UIControlStateNormal];
     btn.frame = CGRectMake(0, 0, 27, 44);
    [btn addTarget:self action:@selector(gotoHomeMenue:)  forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem * homeBtn = [[UIBarButtonItem alloc] initWithCustomView:btn];
    self.navigationItem.rightBarButtonItem = homeBtn;
 
    [super viewDidLoad];
//    CGRect bounds= [[UIScreen mainScreen]bounds];
//    UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, bounds.size.width, bounds.size.height)];
//    imgView.image = [UIImage imageNamed:@"detail.png"];
//    self.view.backgroundColor= [UIColor clearColor];
//    [self.view addSubview:imgView];
    
    self.contentTextView.backgroundColor=[UIColor clearColor];
    //[self.contentTextView setTextColor:[UIColor whiteColor]];
    [self.contentTextView setEditable:false];
//    [self.view bringSubviewToFront:self.textView];
//    [self.view bringSubviewToFront:self.contentHeading];
    [self.contentTextView setScrollEnabled:YES];
    [self renderContent];
    
       // Do any additional setup after loading the view from its nib.
}
-(void) renderContent
{
//    self.fileName = [NSString stringWithFormat:@"%@-%@",self.fileName,self.title];
   
    self.contentHeading.text = self.heading;
        
    // Parse text to apply formatting
    NSString * content = [DataSource getDetailFile:self.fileName];
    NIHTMLParser * parser = [[NIHTMLParser alloc]initWithString: content];
    
    NSAttributedString * attStr = [parser.body attributedString];

    NSMutableAttributedString * str = [[NSMutableAttributedString alloc]initWithAttributedString:attStr];
    
    // Apply white color to text and font size
    [str addAttribute:(id)kCTForegroundColorAttributeName value:(id)[UIColor whiteColor].CGColor range:NSMakeRange(0, str.length)];
    //[str addAttribute:(id)kCTFontAttributeName value:[UIFont systemFontOfSize:fontSize] range:NSMakeRange(0, str.length)];
    
    if(str != nil)
        [self.contentTextView setAttributedString:str];
    
    [parser release];
    [str release];
    
//    UIAlertView * alrt = [[UIAlertView alloc]initWithTitle:nil message:[[DataSource getDetailFile:self.fileName] unicodeToString] delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles: nil];
//    [alrt show];
//    [alrt release];
    
//    NSArray *contentArray = [DataSource getContent:self.fileName];
//    
//    if(contentArray.count>0){
//        for (int i=0; i<contentArray.count; i++) {
//            if ([[contentArray objectAtIndex:i] rangeOfString:@"@@image@@"].location!=NSNotFound) {
//                //add image view
//            }
//            else{
//                //add text view
//            }
//        }
//        //        self.detailViewController.textView.text = text;
//    }
}
-(IBAction)gotoHomeMenue:(id)sender
{
    [self.navigationController dismissModalViewControllerAnimated:YES];
    NSLog(@"goto home menu");
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [_textView release];
    [_contentHeading release];
    [_contentTextView release];
    [_textContainerView release];
    [super dealloc];
}
- (void)viewDidUnload {
//    [self setTextView:nil];
    [self setContentHeading:nil];
    [self setContentTextView:nil];
    [self setTextContainerView:nil];
    [super viewDidUnload];
}
-(void) imageFrame:(CGRect )frame
{
    
}
-(CGRect)getImageFrame
{
    //return image view width, height
    return CGRectMake(0, 0, 200, 200);
}

- (IBAction)increaseFontButtonTapped:(id)sender {
    int fontSize = [[NSUserDefaults standardUserDefaults]integerForKey:@"FontSize"];
    if(fontSize >= 30)
        return;
    
    fontSize += 2;
    
    [[NSUserDefaults standardUserDefaults]setInteger:fontSize forKey:@"FontSize"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
     [self renderContent];
}

- (IBAction)decreaseFontButtonTapped:(id)sender {
    int fontSize = [[NSUserDefaults standardUserDefaults]integerForKey:@"FontSize"];
    if(fontSize <= 10)
        return;
    
    fontSize -= 2;
    
    [[NSUserDefaults standardUserDefaults]setInteger:fontSize forKey:@"FontSize"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    [self renderContent];
}
@end
