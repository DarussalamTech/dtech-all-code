//
//  CheckListViewController.h
//  Ramadan
//
//  Created by Faiz Rasool on 5/23/13.
//  Copyright (c) 2013 Kjuly. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomCellViewController.h"
#import "CheckListItem.h"
#import "DataSource.h"

@interface CheckListViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>
{
    CustomCellViewController *cell;
}
@property (retain, nonatomic) IBOutlet UITableView *tasksTableView;
@property (retain, nonatomic) IBOutlet UILabel *dayLabel;

@property (retain, nonatomic) NSMutableArray * dataSource;

@property (nonatomic) int selectedCategory;
@property (retain, nonatomic) NSMutableArray * sections;
@property (nonatomic, retain) DataSource * DBSource;

@property (nonatomic, strong) NSDate * today;
@property (nonatomic, strong) NSDate * selectedDate;

@property (retain, nonatomic) IBOutlet UIView *navigationView;
@property (retain, nonatomic) IBOutlet UILabel *headerTitleLabel;

- (IBAction)nextDayButtonTapped:(id)sender;
- (IBAction)previousDayButtonTapped:(id)sender;

- (void) getChecklistItemsForDate:(NSString*)date;

@end
