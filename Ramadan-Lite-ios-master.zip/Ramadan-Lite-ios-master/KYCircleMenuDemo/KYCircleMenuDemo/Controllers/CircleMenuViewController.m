//
//  CircleMenuViewController.m
//  KYCircleMenuDemo
//
//  Created by Kjuly on 7/18/12.
//  Copyright (c) 2012 Kjuly. All rights reserved.
//

#import "CircleMenuViewController.h"
#import "CheckListViewController.h"

@implementation CircleMenuViewController

- (void)dealloc {
  [super dealloc];
}

- (id)init {
    if (self = [super init]){
    [self setTitle:@"Ramadan"];
     
    
    }
  return self;
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    CGRect frame = [[UIScreen mainScreen] bounds];
    frame.origin.x = 0;
    frame.origin.y = 0;
    [self.bgImageView setFrame:frame];
}

- (void)viewDidLoad {
   
    [super viewDidLoad];
    
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(playBackEnded:) name:MPMoviePlayerPlaybackDidFinishNotification object:nil];
    
    
    //initialize dataSource
    if([[UIScreen mainScreen]bounds].size.height > 480)
        self.bgImageView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"home-bg@2x.png"]];
    else
        self.bgImageView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"home-bg@2x.png"]];
    
    [self.bgImageView setFrame:[UIScreen mainScreen].bounds];
    
    [self.view addSubview:self.bgImageView];
    [self.view sendSubviewToBack:self.bgImageView];

  // Modify buttons' style in circle menu
  for (UIButton * button in [self.menu subviews])
    [button setAlpha:.95f];
    CGRect frame = self.centerButton.frame;
    frame.origin.y += 45;
    self.centerButton.frame = frame;
    
    CGRect viewFrame = self.menu.frame;
    viewFrame.origin.y += 45;
    self.menu.frame = viewFrame;
    
   // self.menu.center = CGPointMake(self.menu.center.x, self.menu.center.y+30);
    
//    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
//    bool isFirstRun = [userDefaults boolForKey:@"isFirstRun"];
//    if (isFirstRun==YES) {
//      // do nothing
//        
//    }
//    else{
//        [self performSelector:@selector(playStartMovie) withObject:nil afterDelay:kSplashDelay];
//    }
}

- (void) playStartMovie{
       
    NSBundle *bundle=[NSBundle mainBundle];
    NSString *moviePath = [bundle pathForResource:@"sample" ofType:@"m4v"];
    NSURL *url=[NSURL fileURLWithPath:moviePath] ;
    
    MPMoviePlayerViewController *m_player = [[MPMoviePlayerViewController alloc] initWithContentURL:url];
    //    [m_player.backgroundView setBackgroundColor:[UIColor blackColor]];
    [m_player.view setBackgroundColor:[UIColor blackColor]];
    m_player.moviePlayer.controlStyle =MPMovieControlStyleNone;
    //    [m_player setControlStyle:MPMovieControlStyleNone];
    //    m_player.scalingMode = MPMovieControlStyleFullscreen;
    //    m_player.scalingMode = MPMovieScalingModeAspectFill;
    m_player.view.frame = self.view.frame;
    [self.view addSubview:m_player.view];
    //    [self.view bringSubviewToFront:m_player.view];

}

- (void) playBackEnded:(NSNotification*)notif{
    
    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"isFirstRun"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    MPMoviePlayerViewController * player = (MPMoviePlayerViewController*)notif.object;
    [player.view removeFromSuperview];
}

- (void)didReceiveMemoryWarning {
  [super didReceiveMemoryWarning];
  // Dispose of any resources that can be recreated.
}

#pragma mark - KYCircleMenu Button Action

// Run button action depend on their tags:
//
// TAG:        1       1   2      1   2     1   2     1 2 3     1 2 3
//            \|/       \|/        \|/       \|/       \|/       \|/
// COUNT: 1) --|--  2) --|--   3) --|--  4) --|--  5) --|--  6) --|--
//            /|\       /|\        /|\       /|\       /|\       /|\
// TAG:                             3       3   4     4   5     4 5 6
//
- (void)runButtonActions:(id)sender {
  [super runButtonActions:sender];
    //[[UIApplication sharedApplication] setStatusBarHidden:NO withAnimation:UIStatusBarAnimationFade];
//
  // Configure new view & push it with custom |pushViewController:| method
    
  //    NSLog(@"arrayLines: %@", lines);
    
    
    if([sender tag] == 5){
        NSArray *lines = [DataSource getContent:@"main"];
        self.subcontentController =[[SubContent alloc]initWithNibName:@"SubContent" bundle:nil];
        NSString *content = [lines objectAtIndex:[sender tag]-1];
        self.subcontentController.title = content;
        self.subcontentController.topics = [[DataSource sharedInstance] getAllCategories];
        
        self.jASPCont = [[[JASidePanelController alloc]init] autorelease];
        
        self.jASPCont.leftPanel = self.subcontentController;
        self.jASPCont.leftFixedWidth = 265;
        
        CheckListViewController * list = [[CheckListViewController alloc]initWithNibName:@"CheckListViewController" bundle:nil];
        [list setDataSource:[[DataSource sharedInstance]getChecklistForCategory:1]];
        [list setSelectedCategory:1];
        self.centerNavController = [[UINavigationController alloc]initWithRootViewController:list];
        self.jASPCont.centerPanel =  self.centerNavController;
        // Use KYCircleMenu's |-pushViewController:| to push vc
        [self presentModalViewController:self.jASPCont animated:YES ];
        // [self.subcontentController release];
        [list release];
    }
    else if([sender tag] == 3){
    NSArray *lines = [DataSource getContent:@"main"];
    self.subcontentController =[[SubContent alloc]initWithNibName:@"SubContent" bundle:nil];
    NSString *content = [lines objectAtIndex:[sender tag]-1];
    self.subcontentController.title = content;
    self.subcontentController.topics = [DataSource getContent:content];
    
   self.jASPCont = [[[JASidePanelController alloc]init] autorelease];
     
    self.jASPCont.leftPanel = self.subcontentController;
    self.jASPCont.leftFixedWidth = 265;
    
    self.detailCont = [[DetailViewController alloc]initWithNibName:@"DetailViewController" bundle:nil];
    self.detailCont.title = content;
//    self.detailCont.view.frame = CGRectMake(0, 44, 320, 524);
    
    self.detailCont.heading  = [self.subcontentController.topics objectAtIndex:0];
    self.detailCont.fileName = [NSString stringWithFormat:@"%@-%@",content,[self.subcontentController.topics objectAtIndex:0]];
    self.centerNavController = [[UINavigationController alloc]initWithRootViewController:self.detailCont];
     self.jASPCont.centerPanel =  self.centerNavController;
  // Use KYCircleMenu's |-pushViewController:| to push vc
   [self presentModalViewController:self.jASPCont animated:YES ];
 // [self.subcontentController release];
    }
    else
    {
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"" message:@"Do you want to buy full version" delegate:self cancelButtonTitle:@"ok" otherButtonTitles:@"Cancel", nil];
            [alert show];
            
    }
        
}
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(buttonIndex==0)
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"https://itunes.apple.com/us/app/enjoy-your-life/id641420396?ls=1&mt=8"] ];
    else
        NSLog(@"user pressed cancel");
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation{
    return toInterfaceOrientation == UIInterfaceOrientationPortrait;
}

@end
