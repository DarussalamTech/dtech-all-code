//
//  AnimationControllerViewController.m
//  Ramadan
//
//  Created by ahadnawaz on 29/04/2013.
//  Copyright (c) 2013 Kjuly. All rights reserved.
//

#import "AnimationViewController.h"
#import "CircleMenuViewController.h"

@interface AnimationViewController ()

@end

@implementation AnimationViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    bool isFirstRun = [userDefaults boolForKey:@"isFirstRun"];
    if (isFirstRun==YES) {
        [self gotoMainMenu ];
       
    }
        else{
        [userDefaults setBool:YES forKey:@"isFirstRun"];
        
         NSBundle *bundle=[NSBundle mainBundle];
        NSString *moviePath = [bundle pathForResource:@"sample" ofType:@"m4v"];
         NSURL *url=[NSURL fileURLWithPath:moviePath] ;
        
        MPMoviePlayerViewController *m_player = [[MPMoviePlayerViewController alloc] initWithContentURL:url];
    //    [m_player.backgroundView setBackgroundColor:[UIColor blackColor]];
        [m_player.view setBackgroundColor:[UIColor blackColor]];
        m_player.moviePlayer.controlStyle =MPMovieControlStyleNone;
    //    [m_player setControlStyle:MPMovieControlStyleNone];
    //    m_player.scalingMode = MPMovieControlStyleFullscreen;
    //    m_player.scalingMode = MPMovieScalingModeAspectFill;
         m_player.view.frame = self.view.frame;
         [self.view addSubview:m_player.view];
    //    [self.view bringSubviewToFront:m_player.view];
        }
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}


-(void) gotoMainMenu
{
    
    
    // Circle Menu
    CircleMenuViewController * circleMenuViewController;
    circleMenuViewController = [CircleMenuViewController alloc];
    
    // Setup circle menu with basic configuration
    [circleMenuViewController initWithButtonCount:kKYCCircleMenuButtonsCount
                                         menuSize:kKYCircleMenuSize
                                       buttonSize:kKYCircleMenuButtonSize
                            buttonImageNameFormat:kKYICircleMenuButtonImageNameFormat
                                 centerButtonSize:kKYCircleMenuCenterButtonSize
                            centerButtonImageName:kKYICircleMenuCenterButton
                  centerButtonBackgroundImageName:kKYICircleMenuCenterButtonBackground];

    // Set the cricle menu vc as the root vc
    // Navigation Controller
    UINavigationController * navigationController = [[UINavigationController alloc]initWithRootViewController:circleMenuViewController];
    [navigationController.navigationBar setBarStyle:UIBarStyleBlackTranslucent];

    navigationController.view.frame = [UIScreen mainScreen].bounds;
    
      [self.view addSubview:navigationController.view];
//    [navigationController release];
    [circleMenuViewController release];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
