//
//  CustomTextView.h
//  EnjoyYourLife
//
//  Created by Faiz Rasool on 4/26/13.
//  Copyright (c) 2013 Darussalam Publications. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreText/CoreText.h>


#define kMinFontSize 10
#define kMaxFontSize 30
#define kFontIncreaseFactor 0.4

@interface CustomTextView : UITextView

@property (nonatomic, strong) UIPinchGestureRecognizer * gesture;

@end
