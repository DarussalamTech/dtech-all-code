//
//  CircleMenuViewController.h
//  KYCircleMenuDemo
//
//  Created by Kjuly on 7/18/12.
//  Copyright (c) 2012 Kjuly. All rights reserved.
//

#import "KYCircleMenu.h"
#import "DataSource.h"
#import "SubContent.h"
#import "JASidePanelController.h"
#import "DetailViewController.h"
#import <MediaPlayer/MediaPlayer.h>

@interface CircleMenuViewController : KYCircleMenu <UIAlertViewDelegate>

 
@property (nonatomic,strong) SubContent *subcontentController;

@property (nonatomic,strong) JASidePanelController *jASPCont;
@property (nonatomic,strong) DetailViewController *detailCont;
@property (nonatomic,strong) UINavigationController * centerNavController;
@property (nonatomic,strong) UIImageView *  bgImageView;

@end
