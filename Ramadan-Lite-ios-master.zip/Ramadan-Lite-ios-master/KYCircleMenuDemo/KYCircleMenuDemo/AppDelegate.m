//
//  AppDelegate.m
//  KYCircleMenuDemo
//
//  Created by Kjuly on 7/18/12.
//  Copyright (c) 2012 Kjuly. All rights reserved.
//

#import "AppDelegate.h"

#import "CircleMenuViewController.h"
#import "AnimationViewController.h"

@implementation AppDelegate

- (void)dealloc {
  [_window release];
  [super dealloc];
}

- (BOOL) application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    [[UINavigationBar appearance] setBackgroundImage:[UIImage imageNamed:@"top-strop-1.png"] forBarMetrics:UIBarMetricsDefault];

    [DataSource checkAndCreateDatabase];
    
    // set default font size
    NSUserDefaults * userDefaults = [NSUserDefaults standardUserDefaults];
    [userDefaults setInteger:16 forKey:@"FontSize"];
    [userDefaults synchronize];
    
    
  self.window = [[[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]] autorelease];
    [[UINavigationBar appearance] setBarStyle:UIBarStyleBlack];
  // Override point for customization after application launch.
  
//  // Navigation Controller
  UINavigationController * navigationController = [UINavigationController alloc];

  // Circle Menu
  CircleMenuViewController * circleMenuViewController;
  circleMenuViewController = [CircleMenuViewController alloc];
  // Set the cricle menu vc as the root vc
  [navigationController initWithRootViewController:circleMenuViewController];
  
  // Setup circle menu with basic configuration
  [circleMenuViewController initWithButtonCount:kKYCCircleMenuButtonsCount
                                       menuSize:kKYCircleMenuSize
                                     buttonSize:kKYCircleMenuButtonSize
                          buttonImageNameFormat:kKYICircleMenuButtonImageNameFormat
                               centerButtonSize:kKYCircleMenuCenterButtonSize
                          centerButtonImageName:kKYICircleMenuCenterButton
                centerButtonBackgroundImageName:kKYICircleMenuCenterButtonBackground];

//
    [circleMenuViewController.navigationController setNavigationBarHidden:NO];
  // Set navigation controller as the root vc
  [self.window setRootViewController:navigationController];
//    AnimationViewController *cont =[[AnimationViewController alloc]initWithNibName:@"AnimationViewController" bundle:nil];
//    
//    [self.window setRootViewController:cont];
//  [navigationController release];
  
  [self.window makeKeyAndVisible];
  [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleBlackOpaque];
   [self showSplashView];
      [circleMenuViewController release];
  return YES;
}
- (void) showSplashView{
    self.splash = [[SplashView alloc]initWithFrame:self.window.frame];
    self.splash.delay = kSplashDelay;
    self.splash.touchAllowed = NO;
    self.splash.animation = SplashViewAnimationFade;
    [self.splash startSplash];
}

@end
