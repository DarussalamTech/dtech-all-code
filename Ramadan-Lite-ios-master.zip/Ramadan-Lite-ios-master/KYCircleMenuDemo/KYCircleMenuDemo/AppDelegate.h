//
//  AppDelegate.h
//  KYCircleMenuDemo
//
//  Created by Kjuly on 7/18/12.
//  Copyright (c) 2012 Kjuly. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SplashView.h"
//#import "JASidePanelController.h"
//#import "SubContent.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow * window;
@property (strong ,nonatomic) SplashView *splash;
@end
