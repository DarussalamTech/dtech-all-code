//
//  DataSource.h
//  Ramadan
//
//  Created by ahadnawaz on 29/04/2013.
//  Copyright (c) 2013 Kjuly. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "EGODatabase.h"
#import "CheckListItem.h"

#define dataBaseName @"RamadanData"
#define fullDataBaseName @"RamadanData.sqlite"

@interface DataSource : NSObject

+ (DataSource*)sharedInstance;
+(NSArray *) getContent:(NSString *)fileName;
+(NSString *) getDetailFile:(NSString *)fileName;

+(void)checkAndCreateDatabase;
+ (NSString*) getDatabasePath;

- (NSMutableArray*) getChecklistForCategory:(int)categoryID;
- (NSMutableArray*) getChecklistForDate:(NSString*)date;
- (NSMutableArray*) getAllCategories;
- (void) markTaskAsDone:(int)checklistID categoryID:(int)catID date:(NSString*)dateMarked;
- (void) unMarkTask:(int)checklistID categoryID:(int)catID date:(NSString*)dateMarked;
@end